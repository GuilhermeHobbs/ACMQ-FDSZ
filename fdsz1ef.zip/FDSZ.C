/* Filters Design in S or Z */
/* By Antonio Carlos M. de Queiroz */
/*
   Version 1.0-In development in 11/11/95
   Version 1.0a - 08/04/95: Better irregular filter editor
     Added Ntchangef*. How to limit the range, given px and py?
     Added zoom out in the frequency response, in the event handler.
   Version 1.0b - 28/10/96: Biquad structure plotted, first order sections.
   Version 1.0c - 05/11/96: Sampling rate saved with multipliers. Small changes.
   Version 1.0d - 16/11/96: Digital instead of discrete.
   Version 1.0e - 26/04/99: Space works as MS_MIDDLE.
   Version 1.0f - 08/12/99: F(s) and F(z) can be listed and saved.
   To do:
   Roots editor?
   Compute Q for discrete approximations, and sort roots by Q.
   Predesign what is usually the optimum biquad pairing.
   Add button to clear design. Or to not plot design.
   Improve the editor for irregular filter design. Plot?
   Analyze and filter .wav files.
   Plot limits for K(jw)?
   Impede too low sampling frequency? Not necessary.
   Organize better the tolerances and normalizations.
   Improve the precision of the root finder for multiple roots.
     Difficult.
     Al least impede infinite loop.
   Implement Bessel filters. Versions with transformations and digital?
*/

#define version "1.0e - 26/04/99"

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "mickey.h"
#include "xview.h"
#include "notice.h"
#include "xv_var.h"
#include "extkeys.h"

/* Program limits */
#define nmax 40
#define tolr "1e-11"
#define tolrmax "1e-9"
#define tolo "1e-11"
#define tolm 1e-12
#define told 1e-7
#define XR0 -1.1
#define XI0 1.1
#define IMAX 50
#define IKMAX 1
#define maxdesigns 5
#define xxmax 399
#define xd 15
#define yd 12

/* Colors */
int cor[9]={WHITE,YELLOW,LIGHTBLUE,GREEN,LIGHTCYAN,LIGHTRED,LIGHTMAGENTA,LIGHTGRAY,BLACK};
#define c_line cor[7]
#define c_limit cor[1]
#define c_text cor[0]
#define c_background cor[8]
#define c_barriers cor[5]
#define c_cursor cor[6]
#define c_marker cor[1]
#define c_gain cor[0]
#define c_phase cor[1]
#define c_delay cor[3]
#define c_roots cor[6]

/* Booleans */
#define boolean int
#define true 1
#define false 0

#define ldouble long double

/* Interface access */
#define set_sel(xx,yy) xx->v.ssetting.sel_setting=yy
#define set_int(xx,yy) xx->v.stextfield.panel_int=yy
#define set_real(xx,yy) xx->v.stextfield.panel_real=(double)yy
#define set_value(xx,yy) strcpy(xx->v.stextfield.panel_value,yy)
#define set_label(xx,yy) xv_set(xx,yy)
#define set_max(xx,yy) xx->v.stextfield.max_value=yy
#define get_dx(xx) xx->dx
#define get_dy(xx) xx->dy
#define get_real(xx) (ldouble)xx->v.stextfield.panel_real
#define get_int(xx) xx->v.stextfield.panel_int
#define get_value(xx) xx->v.stextfield.panel_value
#define get_sel(xx) xx->v.ssetting.sel_setting
#define update(xx) xv_set(xx,xx->xv_label)

#define LOG (slog->v.ssetting.sel_setting==2)
#define PHASE ((splot->v.ssetting.sel_setting & 4)==4)
#define DELAY ((splot->v.ssetting.sel_setting & 8)==8)
#define RADS (sHertz->v.ssetting.sel_setting==2)
#define DISCRETE(xx) (filter[xx].anadig>1)
#define BILINEAR(xx) (filter[xx].anadig==2)
#define LDI(xx) (filter[xx].anadig==3)
#define BYTYPE (scolor->v.ssetting.sel_setting==1)
#define PLOTK (sfunction->v.ssetting.sel_setting==2)
#define SHOWK (sk->v.ssetting.sel_setting==2)

#ifdef __TURBOC__
extern unsigned _stklen=40000u; /*Tamanho da stack*/
#endif
#ifdef __GNUC__
extern int _stklen=64000;
#endif

/* Structures */
typedef ldouble Matriz[nmax+1][nmax+1];
typedef ldouble valores[nmax+1];
typedef ldouble coeff[nmax+1];

typedef struct roots {
  coeff re,im;
} roots;
typedef struct polynomial {
  int grau;
  ldouble cte;
  coeff a;
} polynomial;
typedef struct section {
  int pole[2];
  int zero[2];
  ldouble a2,a1,a0,b2,b1,b0,gain,max;
  int ga;
} section;
typedef struct design {
  char title[60];                       /* title */
  int type,pol,inv,rat,order,anadig;    /* parameters */
  ldouble sampling;                     /* sampling rate */
  polynomial Es,Ps,Fs,Ez,Pz,Fz,Xw,Yw;   /* polynomials */
  roots rek,rpk,rfk;                    /* roots; 0 not used */
  ldouble normalization;                /* normalization factor */
  ldouble *Gan,*Ang,*Tg;                /* curves */
  int ga,fa,ta;                         /* for the plot */
  int n,px,py;                          /* order and zeros at o of X and Y */
  ldouble Amax,Amin,epsilon,alfa;       /* attenuation parameters */
  valores fx,fy,wx,wy;                  /* extremes and frequencies */
  int nz,np,nb;                         /* number of poles and zeros and biquads*/
  section biquad[nmax/2];               /* cascade of biquads */
  boolean valid,realized;
} design;

/* Declaration of the interface objects */
Xv_opaque menu1;
Xv_opaque fio,tfilename,bfileio;
Xv_opaque fparameters,twmin,twmax,tgmin,tgmax,
  slog,sHertz,tdmin,tdmax,splot,tsegmf,scolor,sfunction,sk,
  bapplyparameters;
Xv_opaque froots,croots;
Xv_opaque fhplimits,thpf1,thpf2,bapplyfhp;
Xv_opaque flplimits,tlpf1,tlpf2,bapplyflp;
Xv_opaque fbrlimits,tbrf1,tbrf2,tbrf3,tbrf4,
  bapplyfbr;
Xv_opaque fbplimits,tbpf1,tbpf2,tbpf3,tbpf4,
  bapplyfBP;
Xv_opaque fapproximation,stype,spolynomial,sinverse,srational,torder,
  sanadig,tsampling,bapplyapprox,tamin,tamax,ttitle,tnumber;
Xv_opaque fmessages,tty1;
Xv_opaque ffrequency,cfrequency;
Xv_opaque fprecision,timax,ttolr,ttolrmax,tikmax,ttolo;
Xv_opaque firregular,tpx,tpy,tchangefx,tchangefy,tfxto,tfyto,
  tchangeAx,tchangeAy,blistf,bcomplete,bhelpirr;
Xv_opaque fbiquad,cbiquad,bbiquad,bhelpbiquad;
Xv_opaque fcircuit,mcircuit;

/* Global variables */
boolean convergiu_direto=false, error=false,
frequency_valid=false;
ldouble aw,bw,ag,bg,ad,bd,ap,bp,ah,bh,dw,ax,bx,ay,by;
int fxmin,fxmax,fymin,fymax;
int rxmin,rxmax,rymin,rymax;
design filter[maxdesigns];
polynomial x,y,z,t;
roots zt;
ldouble ztnorm;
ldouble tolr1;
long int riter,optiter;
int cedit=0;
char nameedit[6];
ldouble tymin=-2,txmin=-2,tdelta=4;
FILE *archive;
ldouble Imag;
char cc;
int fcsr,ultpt=-1,inuse,ndesigns,fcolcsr,fycsr;
ldouble Frq[xxmax+1];
int xcsr,ycsr;

/* To allow use of printf in the tty */
void XPRINTF(char* format,...)
{
  char teste[256];
  va_list paramlist;

  va_start(paramlist,format);
  vsprintf(teste,format,paramlist);
  ttysw_output(tty1,teste);
}
#define printf XPRINTF

extern long int maxavail();

/* Normal Procedures */

ldouble Cmult(ldouble x1, ldouble x2, ldouble y1, ldouble y2)
{
  Imag=x1*y2+x2*y1;
  return x1*y1-x2*y2;
}

ldouble Cdiv(ldouble a1,ldouble a2,ldouble b1,ldouble b2)
{
  ldouble t;

  if (b1==0.0 || b2==0.0) {
    t=1/(b1*b1+b2*b2);
    Imag=(a2*b1-a1*b2)*t;
    return (a1*b1+a2*b2)*t;
  }
  t=1/(b1/b2+b2/b1);
  Imag=(a2/b2-a1/b1)*t;
  return (a1/b2+a2/b1)*t;
}

void SavePolynomial(char *name, char *suffix, polynomial *x, ldouble norm)
{
  FILE *archive;
  int i;
  char fname[60];

  sprintf(fname,"%s.%s",name,suffix);
  archive=fopen(fname,"w");
  fprintf(archive,"%d\n",x->grau);
  for (i=0; i<=x->grau; i++)
    fprintf(archive,"%20.15Lf\n",x->a[i]);
  fprintf(archive,"%20.15Lf\n%20.15Lg\n",x->cte,norm);
  fclose(archive);
  printf("Polynomial saved in file %s\n",fname);
}

void SaveRoots(char *name, char *suffix, roots *z, polynomial *p, ldouble norm)
{
  FILE *archive;
  int i;
  char fname[60];

  sprintf(fname,"%s.%s",name,suffix);
  archive=fopen(fname,"w");
  fprintf(archive,"%d\n",p->grau);
  for (i=1; i<=p->grau; i++)
    fprintf(archive,"%20.15Lf %20.15Lf\n",z->re[i],z->im[i]);
  fprintf(archive,"%20.15Lf\n%20.15Lg",p->cte,norm);
  fclose(archive);
  printf("Roots saved in file %s\n",fname);
}

void SaveBiquads(design *item)
{
  FILE *archive;
  char fname[60];
  section *biq;
  int i;

  sprintf(fname,"%s.%s",item->title,"biq");
  archive=fopen(fname,"w");
  fprintf(archive,"NB %d\nNO %20.15Lg\n",item->nb,item->anadig==1?item->normalization:1);
  for (i=1; i<=item->nb; i++) {
    biq=&item->biquad[i];
    fprintf(archive,"b2%d %20.15Lf\nb1%d %20.15Lf\nb0%d %20.15Lf\na2%d %20.15Lf\na1%d %20.15Lf\na0%d %20.15Lf\n",
            i,biq->b2,i,biq->b1,i,biq->b0,i,biq->a2,i,biq->a1,i,biq->a0);
  }
  fclose(archive);
  printf("Biquads saved in file %s\n",fname);
}

void ComputeMultipliers(design *item)
{
  FILE *archive;
  char fname[60];
  section *biq;
  int i;
  ldouble A,C,F,L,B,H;

  sprintf(fname,"%s.%s",item->title,"mul");
  archive=fopen(fname,"w");
  fprintf(archive,"SR %20.3Lf\nNB %d\n",item->sampling,item->nb);
  printf("Biquad multipliers:\n");
  for (i=1; i<=item->nb; i++) {
    biq=&item->biquad[i];
    printf("Session %d: %s %s\n",i,(biq->a2==0)?"first":"second","order");
    if (biq->a2==0) {
      if (biq->b2!=0) printf("* A first-order section cannot have two zeros.\n");
      else {
        A=1;
        C=0;
        F=biq->a0+1;
        L=0;
        B=biq->b0+biq->b1;
        H=biq->b1;
        goto lprint;
      }
    }
    else {
      A=1+biq->a0+biq->a1;
      if (A<=0) printf("* The design of biquad #%d is not possible.\n",i);
      else {
        A=sqrtl(A);
        C=A;
        F=(2+biq->a1)/A;
        L=(biq->b2+biq->b1+biq->b0)/A/C;
        B=(biq->b1+2*biq->b2)/A;
        H=biq->b2;
       lprint:
        fprintf(archive,"A%d %20.15Lf\nC%d %20.15Lf\nF%d %20.15Lf\nL%d %20.15Lf\nB%d %20.15Lf\nH%d %20.15Lf\n",
              i,A,
              i,C,
              i,F,
              i,L,
              i,B,
              i,H);
         printf("A%d %20.15Lf\nC%d %20.15Lf\nF%d %20.15Lf\nL%d %20.15Lf\nB%d %20.15Lf\nH%d %20.15Lf\n",
              i,A,
              i,C,
              i,F,
              i,L,
              i,B,
              i,H);
        }
    }
  }
  fclose(archive);
  printf("Biquad multipliers saved in file %s\n",fname);
}

void ListPolynomial(char *nome, polynomial *x)
{
  int i;
  printf("Polynomial %s:\n",nome);
  for (i=0; i<=x->grau; i++)
    printf("a(%d): %Lg\n",i,x->a[i]);
  printf("cte: %Lg\n",x->cte);
}

void ListRoots(char *name, roots *z, polynomial *p)
{
  int i;
  ldouble w,TEMP,TEMP1;

  printf("Roots of %s:\n",name);
  for (i=1; i<=p->grau; i++)
    printf("x(%2d):%Lg %Lgj\n",i,z->re[i],z->im[i]);
  for (i=1; i<=p->grau; i++) {
    if (z->im[i]>tolm && fabsl(z->re[i])>tolm) {
      TEMP=z->re[i];
      TEMP1=z->im[i];
      w=sqrtl(TEMP*TEMP+TEMP1*TEMP1);
      printf("w,Q(%2d):%Lg %Lg\n",i,w,w/-2/z->re[i]);
    }
  }
}

void ListBiquads(design *item)
{
  int i,j;
  section *biq;

  printf("Realization in cascade of biquads:\n");
  for (i=1; i<=item->nb; i++) {
    biq=&item->biquad[i];
    printf("Section %d:\n",i);
    for (j=0; j<2; j++) if (biq->pole[j])
      printf("  Pole: %Lg %Lgj\n",
        item->rek.re[biq->pole[j]],
        item->rek.im[biq->pole[j]]);
    for (j=0; j<2; j++) if (biq->zero[j])
      printf("  Zero: %Lg %Lgj\n",
        item->rpk.re[biq->zero[j]],
        item->rpk.im[biq->zero[j]]);
    printf("  Gain: %Lg\n",biq->gain);
  }
  printf("Biquad coefficients:\n");
  for (i=1; i<=item->nb; i++) {
    biq=&item->biquad[i];
    printf("Section %d:\nb2%d %20.15Lf\nb1%d %20.15Lf\nb0%d %20.15Lf\na2%d %20.15Lf\na1%d %20.15Lf\na0%d %20.15Lf\n",
           i,i,biq->b2,i,biq->b1,i,biq->b0,i,biq->a2,i,biq->a1,i,biq->a0);
  }
}

void Inverter(polynomial *x)
{
  ldouble tmp;
  long i,FORLIM;

  FORLIM=x->grau/2;
  for (i=0; i<=FORLIM; i++) {
    tmp=x->a[i];
    x->a[i]=x->a[x->grau-i];
    x->a[x->grau-i]=tmp;
  }
}

void Somar(void)
{
  long i;

  for (i=x.grau+1; i<=y.grau; i++)
    x.a[i]=0.0;
  if (x.grau<y.grau)
    x.grau=y.grau;
  for (i=0; i<=y.grau; i++)
    x.a[i]=x.cte*x.a[i]+y.cte*y.a[i];
  x.cte=1.0;
  y=z;
  z=t;
}

void Negar(void)
{
  x.cte=-x.cte;
}

void Subtrair(void)
{
  Negar();
  Somar();
}

void Multiplicar(void)
{
  coeff m;
  long i,j,FORLIM;

  memcpy(m,x.a,sizeof(coeff));
  FORLIM=x.grau+y.grau;
  for (i=0; i<=FORLIM; i++)
    x.a[i]=0.0;
  for (i=0; i<=x.grau; i++) {
    for (j=0; j<=y.grau; j++)
      x.a[i+j]+=m[i]*y.a[j];
  }
  x.cte*=y.cte;
  x.grau+=y.grau;
  memcpy(&y,&z,sizeof(polynomial));
  memcpy(&z,&t,sizeof(polynomial));
}

void Limpar(polynomial *x)
{
  ldouble max;
  int i;

  max=0.0;
  for (i=0; i<=x->grau; i++) {
    if (fabsl(x->a[i])>max)
      max=fabsl(x->a[i]);
  }
  max*=tolm;
  for (i=0; i<=x->grau; i++) {
    if (fabsl(x->a[i])<max)
      x->a[i]=0.0;
  }
  while (x->grau>=0 && x->a[x->grau]==0)
    x->grau--;
}

void Derivar(void)
{
  int i;

  if (x.grau==0) {
    x.a[0]=0.0;
    return;
  }
  for (i=1; i<=x.grau; i++)
    x.a[i-1]=x.a[i]*i;
  x.grau--;
}

int nl;
ldouble tl, ul, vl, dl;

void Resolve(void)
{
  dl=ul*ul-4*vl;
  if (dl>=0) {
    zt.re[nl]=(sqrtl(dl)-ul)/2;
    zt.re[nl-1]=(-ul-sqrtl(dl))/2;
    zt.im[nl]=0.0;
    zt.im[nl-1]=0.0;
  } else {
    zt.re[nl]=ul/-2;
    zt.re[nl-1]=ul/-2;
    zt.im[nl]=sqrtl(-dl)/2;
    zt.im[nl-1]=-zt.im[nl];
  }
  nl-=2;
}

void RootsLib(void)
{
  /*Ra�zes do polynomial x por Linn-Barstow*/
  int i,j;
  ldouble u1,v1,c1,c2,c3;
  coeff ca,cb;

  nl=x.grau;
  if (nl==0) return;
  tolr1=get_real(ttolr); riter=0;
  for (i=0; i<=x.grau; i++) ca[i]=(ldouble)x.a[i];
  vl=XR0*XR0+XI0*XI0;
  ul=-XR0-XI0;
  while (ca[0]==0 && nl>1) {
    zt.re[nl]=0.0;
    zt.im[nl]=0.0;
    nl--;
    for (j=0; j<=nl; j++)
      ca[j]=ca[j+1];
  }
  do {
    if (nl==1) {
      zt.re[1]=-(ca[0]/ca[1]);
      zt.im[1]=0.0;
      goto End;
    }
    if (nl==2) {
      ul=ca[1]/ca[2];
      vl=ca[0]/ca[2];
      Resolve();
      goto End;
    }
    i=0;
    do {
      if (i>=get_int(timax)) {
	if (tolr1<get_real(ttolrmax)) {
	  tolr1*=10;
	}
	vl=(ldouble)(10*(ldouble)rand()/(ldouble)RAND_MAX-5);
	ul=(ldouble)(10*(ldouble)rand()/(ldouble)RAND_MAX-5);
	i=0;
      }
      i++; riter++;
      cb[nl]=ca[nl];
      c2=cb[nl];
      cb[nl-1]=ca[nl-1]-ul*cb[nl];
      c1=cb[nl-1]-ul*c2;
      for (j=nl-2; j>=1; j--) {
	c3=c2;
	c2=c1;
	cb[j]=ca[j]-ul*cb[j+1]-vl*cb[j+2];
	c1=cb[j]-ul*c2-vl*c3;
      }
      cb[0]=ca[0]-ul*cb[1]-vl*cb[2];
      if ((c3!=0) && (c2!=0) && (c1!=0)) {
	u1=(cb[0]/c2-cb[1]/c3)/(c2/c3-c1/c2);
	v1=(cb[1]/c2-cb[0]/c1)/(c2/c1-c3/c2);
      } else {
	dl=c2*c2-c1*c3;
	u1=(cb[0]*c3-cb[1]*c2)/dl;
	v1=(cb[1]*c1-cb[0]*c2)/dl;
      }
      ul-=u1;
      vl-=v1;
      tl=fabsl(u1)+fabsl(v1);
    } while (tl>tolr1);
    Resolve();
    tolr1=get_real(ttolr);
    for (j=0; j<=nl; j++)
      ca[j]=cb[j+2];
  } while (true);
  End:
}


void RootsBiv(boolean duplas)
{
  /*Ra�zes do polynomial x por Birge-Vieta*/
  coeff a1,a2,c1,c2;
  ldouble told1,tolm1,t,p1,p2,d,xr,xi,p,d1,d2,e1,e2;
  boolean feito;
  int i,j,nn,n,ordem;
  ldouble TEMP,TEMP1;

  n=x.grau;
  if (n<1) {
    printf("* No roots to compute\n");
    return;
  }
  tolr1=get_real(ttolr); riter=0;
  if (duplas)
    told1=told;
  else
    told1=tolm;
  tolm1=tolm;
  for (i=0; i<=x.grau; i++) a1[i]=(ldouble)x.a[i];
  ordem=0;
  xr=XR0;
  xi=XI0;
  feito=false;
  nn=0;
  for (i=0; i<=n; i++)
    a2[i]=0.0;
  printf("Roots: [");
  /*Elimina��o de ra�zes na origem*/
  while (n>1 && a1[0]==0) {
    zt.re[n]=0.0;
    zt.im[n]=0.0;
    printf("%d ", n);
    n--;
    for (i=0; i<=n; i++)
      a1[i]=a1[i+1];
  }
  while (!feito) {
    if (n>1) {
      /*Calculo dos valores do polin�mio (p) e de sua derivada (d)*/
      d1=a1[n];
      p1=d1;
      d2=a2[n];
      p2=d2;
      for (i=n-1; i>=0; i--) {
	p1=Cmult(p1,p2,xr,xi)+a1[i];
	p2=Imag+a2[i];
	if (i>0) {
	  d1=Cmult(d1,d2,xr,xi)+p1;
	  d2=Imag+p2;
	}
      }
      /*C�lculo do erro. Esta forma dificulta overflow*/
      if (d1==0 || d2==0) {
	d=d1*d1+d2*d2;
	e1=(p1*d1+p2*d2)/d;
	e2=(p2*d1-p1*d2)/d;
      } else {
	d=d1/d2+d2/d1;
	e1=(p1/d2+p2/d1)/d;
	e2=(p2/d2-p1/d1)/d;
      }
      /*Testa poss�vel ra�z m�ltipla*/
      d=fabsl(d1)+fabsl(d2);
      p=fabsl(p1)+fabsl(p2);
      if (d<told1 && p<tolm1) {
	/*deriva o polin�mio e continua*/
	if (ordem==0) {
	  memcpy(c1,a1,sizeof(coeff));
	  memcpy(c2,a2,sizeof(coeff));
	}
	for (i=1; i<=n; i++) {
	  a1[i-1]=a1[i]*i/n;
	  a2[i-1]=a2[i]*i/n;
	}
	n--;
	ordem++;
	printf("+");
	continue;
      }
      /*Atualiza ra�zes*/
      xr-=e1;
      xi-=e2;
      /*Testa converg�ncia*/
      t=fabsl(e1)+fabsl(e2);
      if (t<tolr1) {
	/*Armazena ra�zes calculadas*/
	for (i=n+ordem; i>=n; i--) {
	  printf("%d ", i);
	  zt.re[i]=xr;
	  zt.im[i]=xi;
	}
	/*Rep�e polin�mio original, se for o caso*/
	if (ordem>0) {
	  memcpy(a1,c1,sizeof(coeff));
	  memcpy(a2,c2,sizeof(coeff));
	  n+=ordem;
	}
	/*Deflaciona polin�mio*/
	for (i=0; i<=ordem; i++) {
	  for (j=n-1; j>=1; j--) {
	    a1[j]=Cmult(xr,xi,a1[j+1],a2[j+1])+a1[j];
	    a2[j]=Imag+a2[j];
	  }
	  n--;
	  for (j=0; j<=n; j++) {
	    a1[j]=a1[j+1];
	    a2[j]=a2[j+1];
	  }
	}
	/*Prepara c�lculo da pr�xima ra�z*/
	if (fabsl(xi)>0.01)
	  xi=-xi;
	else
	  xi=0.1;
	if (ordem>0)   /*evita derivada 0 a seguir*/
	  xr-=0.01;
	ordem=0;
	nn=0;
	continue;
      }
      nn++; riter++;
      /*Demorando a convergir*/
      if (!(nn>get_int(timax)))
	continue;
      if (tolr1<get_real(ttolrmax)) {
	tolr1*=10;
      }
      xr=(ldouble)(10*(ldouble)rand()/(ldouble)RAND_MAX-5);
      xi=(ldouble)(10*(ldouble)rand()/(ldouble)RAND_MAX-5);
      nn=0;
      continue;
    }
    TEMP=a1[1];
    TEMP1=a2[1];
    /*Ultimas ra�zes*/
    d=-(TEMP*TEMP+TEMP1*TEMP1);
    xr=(a1[0]*a1[1]+a2[0]*a2[1])/d;
    xi=(a2[0]*a1[1]-a1[0]*a2[1])/d;
    feito=true;
    nn=0;
    for (i=n+ordem; i>=n; i--) {
      printf("%d ", i);
      zt.re[i]=xr;
      zt.im[i]=xi;
    }
  }
  printf("]\n");
}  /*RootsBiv*/

void SortRoots(roots *z, int n, int re) /* 1=real 2=imag */
{
  boolean ordenado;
  ldouble t;
  int i;

  if (re==1) do {
    ordenado=true;
    for (i=1; i<n; i++)
      if (z->re[i+1]<z->re[i]) {
        t=z->re[i];
        z->re[i]=z->re[i+1];
        z->re[i+1]=t;
        t=z->im[i];
        z->im[i]=z->im[i+1];
        z->im[i+1]=t;
        ordenado=false;
      }
  } while (!ordenado);
  else if (re==2) do {
    ordenado=true;
    for (i=1; i<n; i++)
      if (z->im[i+1]>z->im[i]) {
	t=z->re[i];
	z->re[i]=z->re[i+1];
	z->re[i+1]=t;
	t=z->im[i];
	z->im[i]=z->im[i+1];
	z->im[i+1]=t;
	ordenado=false;
      }
  } while (!ordenado);
}

void ResolverSistema(Matriz H, int n)
{
  int i,j,l, a;
  ldouble t, p;

  error=false;
  for (i=1; i<=n; i++) {
    t=0.0;
    a=i;
    for (l=i; l<=n; l++) {
      if (fabsl(H[l][i])>fabsl(t)) {
	a=l;
	t=H[l][i];
      }
    }
    if (i!=a) {
      for (l=1; l<=n+1; l++) {
	p=H[i][l];
	H[i][l]=H[a][l];
	H[a][l]=p;
      }
    }
    if (fabsl(t)<tolm) {
      printf("* Singular system of equations\n");
      error=true;
      return;
    }
    for (j=n+1; j>i; j--) {
      H[i][j] /= t;
      p=H[i][j];
      for (l=1; l<=n; l++) {
	if (l!=i)
	  H[l][j]-=H[l][i]*p;
      }
    }
  }
}

void Optimize(polynomial *xo, polynomial *yo, ldouble *f, ldouble *w,
  int n, int p, ldouble alfa)
{
  Matriz H;
  valores ultimo_w;
  boolean convergiu;
  ldouble wk, d, tol;
  int m,i,j,iter;
  ldouble TEMP;

  tolr1=get_real(ttolr);
  m=(n-p)/2+1;
  memcpy(ultimo_w,w,sizeof(valores));
  tol=get_real(ttolo);
  memcpy(&x,&(*xo),sizeof(polynomial));
  iter=0;
  do {
    /*===Montar X'(w)Yr(w)-Yr'(w)X(w)===*/
    memcpy(&y,&(*yo),sizeof(polynomial));
    Inverter(&y);
    Limpar(&y);
    memcpy(&z,&x,sizeof(polynomial));
    memcpy(&t,&y,sizeof(polynomial));
    Derivar();
    Multiplicar();
    memcpy(&z,&x,sizeof(polynomial));
    memcpy(&x,&t,sizeof(polynomial));
    Derivar();
    Multiplicar();
    Subtrair();
    Limpar(&x);
    /*===Reduzir grau do polin�mio===*/
    j=p-1;  /*n�mero de zeros na origem de K'(jw)*/
    x.grau=(x.grau-j)/2;
    for (i=0; i<=x.grau; i++) {
      if (i*2+j>=0)
	x.a[i]=x.a[i*2+j];
    }
    /*===Achar freq��ncias de extremo===*/
    RootsLib();
    if (error) return;
    SortRoots(&zt,x.grau,1);
    for (i=1; i<m; i++) {
      if (zt.im[i] != 0)
	printf("* Insufficient precision in roots calculation\n");
      if (zt.re[i]<0)
	printf("* Invalid sequence of extremes\n");
      w[i]=sqrtl(fabsl(zt.re[i]));
    }
    /*===Verificar converg�ncia===*/
    i=1;
    convergiu=true;
    while (convergiu && i<m) {
      d=fabsl(w[i]-ultimo_w[i]);
      /* printf("%2d: %Lg\n",i,d); */
      if (d>tol) {
	convergiu=false;
	convergiu_direto=false;
      }
      i++;
    }
    memcpy(ultimo_w,w,sizeof(valores));
    /*===Montar sistema de equa��es===*/
    for (i=1; i<m; i++) {
      wk=y.a[y.grau];
      for (j=y.grau-1; j>=0; j--)
	wk=wk*w[i]+y.a[j];
      H[i][m+1]=f[i]*wk/alfa;
      wk=1.0;
      for (j=1; j<=p; j++)
	wk*=w[i];
      for (j=1; j<=m; j++) {
	H[i][j]=wk;
	TEMP=w[i];
	wk*=TEMP*TEMP;
      }
    }
    for (i=1; i<=m+1; i++)
      H[m][i]=1.0;
    /*===Resolver sistema de equa��es===*/
    ResolverSistema(H, m);
    if (error) return;
    /*===Copiar solu��o atual para x===*/
    for (i=0; i<=n; i++) x.a[i]=0.0;
    for (i=1; i<=m; i++)
      x.a[p+i+i-2]=H[i][m+1];
    x.grau=n;
    x.cte=1.0;
    iter++;
  } while (!(iter>=get_int(tikmax) || convergiu));
  /*=== Terminar ===*/
Fim:
  memcpy(&(*xo),&x,sizeof(polynomial));
}

void Produto(polynomial *t)
{
  ldouble sinal;
  int i,j,l;

  x.grau=t->grau;
  x.cte=t->cte*t->cte;
  for (i=0; i<=x.grau; i++)
    x.a[i]=0.0;
  for (i=0; i<=t->grau; i++) {
    if (i & 1)
      sinal=-1.0;
    else
      sinal=1.0;
    for (j=0; j<=t->grau; j++) {
      if (!((i+j) & 1)) {
	l=(i+j)/2;
	x.a[l] += t->a[i]*t->a[j]*sinal;
      }
    }
  }
}

void BuildPolynomial(int degree,ldouble ct)
{
  ldouble t;
  int i,j;

  x.cte=ct;
  y.cte=ct;
  y.grau=x.grau=degree;
  for (i=0; i<=x.grau; i++) {
    x.a[i]=0.0;
    y.a[i]=0.0;
  }
  x.a[0]=1.0;
  for (i=1; i<=x.grau; i++) {
    for (j=i; j>=1; j--) {
      t=x.a[j-1]-zt.re[i]*x.a[j]+zt.im[i]*y.a[j];
      y.a[j]=y.a[j-1]-zt.re[i]*y.a[j]-zt.im[i]*x.a[j];
      x.a[j]=t;
    }
    t=zt.im[i]*y.a[0]-zt.re[i]*x.a[0];
    y.a[0]=-zt.re[i]*y.a[0]-zt.im[i]*x.a[0];
    x.a[0]=t;
  }
  t=0.0;
  for (i=0; i<=y.grau; i++) {
    if (fabsl(y.a[i])>t)
      t=fabsl(y.a[i]);
  }
  if (t>tolm)
    printf("* Imprecise polynomial reconstruction\n");
}

void MultC(ldouble c)
{
  x.cte*=c;
}

void HdeK(polynomial *f, polynomial *p, polynomial *e)
{
  ldouble modulo, fase;
  int i;
  ldouble TEMP, TEMP1;

  Produto(f);
  memcpy(&y,&x,sizeof(polynomial));
  Produto(p);
  Somar();
  RootsBiv(false);
  SortRoots(&zt,x.grau,1);
  for (i=0; i<=x.grau; i++) {
    TEMP=zt.re[i];
    TEMP1=zt.im[i];
    modulo=sqrtl(sqrtl(TEMP*TEMP+TEMP1*TEMP1));
    if (zt.im[i]==0 && zt.re[i]==0) fase=0;
    else fase=atan2l(zt.im[i], zt.re[i])/2;
    zt.re[i]=-modulo*cosl(fase);
    zt.im[i]=modulo*sinl(fase);
  }
  ListRoots("E(s)",&zt,&x);
  BuildPolynomial(x.grau,1.0);
  if (f->grau==p->grau)
    MultC(sqrtl(f->cte*f->cte+p->cte*p->cte));
  else
    MultC(f->cte);
  memcpy(&(*e),&x,sizeof(polynomial));
  ListPolynomial("E(s)",&(*e));
}

void ReEscalar(void)
{
  ldouble u, v, w0;
  int i;

  memcpy(&t,&y,sizeof(polynomial));
  memcpy(&z,&x,sizeof(polynomial));
  memcpy(&x,&y,sizeof(polynomial));
  memcpy(&y,&z,sizeof(polynomial));
  Subtrair();
  w0=1.0;
  do {
    u=0.0;
    v=0.0;
    for (i=x.grau; i>=0; i--) {
      u=u*w0+x.a[i];
      if (i!=0)
	v=v*w0+i*x.a[i];
    }
    u/=v;
    w0-=u;
  } while (!(fabsl(u)<get_real(ttolr)));
  memcpy(&x,&y,sizeof(polynomial));
  memcpy(&y,&z,sizeof(polynomial));
  for (i=0; i<x.grau; i++)
    x.a[i]/=powl(w0,x.grau-i);
  for (i=0; i<y.grau; i++)
    y.a[i]/=powl(w0,y.grau-i);
  y.cte/=powl(w0,x.grau-y.grau);
}

void Normalizar(polynomial *x)
{
  int i;

  Limpar(x);
  if (x->grau<0 || x->a[x->grau]==1)
    return;
  x->cte*=x->a[x->grau];
  for (i=0; i<=x->grau; i++)
    x->a[i]/=x->a[x->grau];
}

void ConverterParaS(polynomial *x)
{
  int i,j;

  for (i=0; i<=x->grau; i++) {
    j=i&3;
    if (j==1 || j==2)
      x->a[i]=-x->a[i];
  }
  if (x->a[x->grau]<0) {
    for (i=0; i<=x->grau; i++)
      x->a[i]=-x->a[i];
  }
  x->cte=fabsl(x->cte);
}

void Enter(void)
{
  memcpy(&t,&z,sizeof(polynomial));
  memcpy(&z,&y,sizeof(polynomial));
  memcpy(&y,&x,sizeof(polynomial));
}

void MultS(void)
{
  int i;

  for (i=x.grau; i>=0; i--)
    x.a[i+1]=x.a[i];
  x.a[0]=0.0;
  x.grau++;
}

void Chebyshev(int n)
{
  int k;

  x.a[0]=1.0;
  x.grau=0;
  x.cte=1.0;
  if (n<=0)
    return;
  Enter();
  MultS();
  k=1;
  for (k=2; k<=n; k++) {
    Enter();
    MultC(2.0);
    MultS();
    Enter();
    memcpy(&x,&t,sizeof(polynomial));
    Subtrair();
  }
}

void NormalizedLPApproximation(design *item)
{
  int iter;

  error=false;
  tolr1=get_real(ttolr);
  printf("Optimizing characteristic function...\n");
  iter=0; optiter=0;
  do {
    convergiu_direto=true;
    Optimize(&item->Xw, &item->Yw, item->fx, item->wx, item->n, item->px,
	     item->alfa);
    if (error) return;
    Optimize(&item->Yw, &item->Xw, item->fy, item->wy, item->n, item->py,
	     item->alfa);
    if (error) return;
    iter++; optiter++;
  } while ((!convergiu_direto && iter<=get_int(timax)));
  if (iter>get_int(timax)) printf("* Precision not attained\n");
  ListPolynomial("X(w)",&item->Xw);
  ListPolynomial("Y(w)",&item->Yw);
  memcpy(&x,&(item->Xw),sizeof(polynomial));
  memcpy(&y,&(item->Yw),sizeof(polynomial));
  MultC(item->alfa);
  Inverter(&y);
  Limpar(&y);
  printf("Normalizing LP filter...\n");
  ReEscalar();
  Normalizar(&x);
  Normalizar(&y);
  y.cte=y.cte/x.cte/item->epsilon;
  x.cte=1.0;
  ConverterParaS(&x);
  ConverterParaS(&y);
  memcpy(&(item->Ps),&y,sizeof(polynomial));
  memcpy(&(item->Fs),&x,sizeof(polynomial));
  ListPolynomial("F(s)",&item->Fs);
  ListPolynomial("P(s)",&item->Ps);
  printf("Solving FeldtKeller's equation...\n");
  HdeK(&item->Fs,&item->Ps,&item->Es);
  SortRoots(&zt,x.grau,2);
  memcpy(&(item->rek), &zt, sizeof(roots));
  if (item->Ps.grau>0) {
    printf("Computing transmission zeros...\n");
    memcpy(&x,&(item->Ps),sizeof(polynomial));
    RootsBiv(true);
    memcpy(&(item->rpk),&zt,sizeof(roots));
  }
  printf("Computing attenuation zeros...\n");
  memcpy(&x,&(item->Fs),sizeof(polynomial));
  RootsBiv(true);
  memcpy(&(item->rfk),&zt,sizeof(roots));
  printf("LP filter optimized in %ld iterations\n",optiter);
}

void AproxInic(int n, int p, polynomial *xo)
{
  int j,FORLIM;

  /* m=(n-p)/2+1; */
  if (n&1)
    j=n-p+1;
  else
    j=n-p;
  printf("Initial approximation: w^(%d)*C(%d)(w)\n",n-j,j);
  Chebyshev(j);
  FORLIM=n-j;
  for (j=1; j<=FORLIM; j++)
    MultS();
  memcpy(xo,&x,sizeof(polynomial));
}

void FDefault(int n, int p, ldouble *f)
{
  int i,m;

  m=(n-p)/2+1;
  for (i=1; i<m; i++) {
    if ((m&1) ^ (i&1))
      f[i]=-1.0;
    else
      f[i]=1.0;
  }
}

void InicW(int n, int p, ldouble *w)
{
  int i;

  for (i=(n-p)/2+1; i>0; i--)
    w[i]=1.0;
}

void RedrawFrequency(void);

void LpBpRoots(polynomial *p, roots *r, ldouble B)
{
  int i;
  ldouble t1,t2,ang,mod;

  for (i=1; i<=p->grau; i++) {
    t1=Cmult(r->re[i],r->im[i],r->re[i],r->im[i])*B*B-4;
    t2=Imag*B*B;
    ang=atan2l(t2,t1)/2;
    mod=sqrtl(sqrtl(t1*t1+t2*t2));
    t1=mod*cosl(ang);
    t2=mod*sinl(ang);
    zt.re[2*i-1]=(r->re[i]*B+t1)/2;
    zt.im[2*i-1]=(r->im[i]*B+t2)/2;
    zt.re[2*i]=(r->re[i]*B-t1)/2;
    zt.im[2*i]=(r->im[i]*B-t2)/2;
  }
}

void InvertRoots(polynomial *p, roots *r)
{
  int i,j,k;

  k=p->grau;
  j=1;
  for (i=1; i<=k; i++) {
    if (fabsl(r->re[i])>tolm || fabsl(r->im[i])>tolm) {
      zt.re[j]=Cdiv(1,0,r->re[i],r->im[i]);
      zt.im[j]=Imag;
      j++;
    }
    else
      p->grau--;
  }
}

void BilinearRoots(polynomial *p, roots *r)
{
  int i;
  ldouble t1,t2,T2;

  /* Bilinear transformation: z=(1+(T/2)s)/(1-(T/2)s) */
  T2=filter[inuse].normalization/filter[inuse].sampling/2.0;
  for (i=1; i<=p->grau; i++) {
    t1=r->re[i]*T2;
    t2=r->im[i]*T2;
    zt.re[i]=Cdiv(1+t1,t2,1-t1,-t2);
    zt.im[i]=Imag;
  }
}

void LDIRoots(polynomial *p, roots *r)
{
  int i;
  ldouble t1,t2,T,ang,mdl;

  /* LDI transformation: z=(Ts+sqrt((Ts)^2+4))/2 */
  T=filter[inuse].normalization/filter[inuse].sampling;
  for (i=1; i<=p->grau; i++) {
    t1=Cmult(r->re[i]*T,r->im[i]*T,r->re[i]*T,r->im[i]*T)+4.0;
    t2=Imag;
    ang=atan2l(t2,t1)/2.0;
    mdl=sqrtl(sqrtl(t1*t1+t2*t2));
    t1=(T*r->re[i]+mdl*cosl(ang))/2.0;
    t2=(T*r->im[i]+mdl*sinl(ang))/2.0;
    zt.re[i]=Cmult(t1,t2,t1,t2);
    zt.im[i]=Imag;
  }
}

ldouble warp(ldouble w)
{
  ldouble T;
  if (DISCRETE(inuse)) {
    T=1/filter[inuse].sampling;
    if (!(RADS)) T*=(2*M_PI);
    if (LDI(inuse)) return (2/T)*sinl(w*T/2);
    else return (2/T)*tanl(w*T/2);
  }
  else return w;
}

void CompleteDesign(design* item)
{
  int i,temp;
  ldouble tt,tf,B,tn,a1,a2,b1,b2,c1,c2,z1,w;

  if (!item->valid) {
    printf("X(w): ");
    AproxInic(item->n, item->px, &item->Xw);
    printf("Y(w): ");
    AproxInic(item->n, item->py, &item->Yw);
  }
  InicW(item->n, item->px, item->wx);
  InicW(item->n, item->py, item->wy);
  if (get_sel(stype)>2 && get_int(torder)*2>nmax) {
    printf("* Too high order\n");
    error=true;
  }
  else NormalizedLPApproximation(item);
  if ((item->valid=!error)!=0) {
    switch(get_sel(stype)) {
      case 1:/*Low-pass*/
	item->normalization=warp(get_real(tlpf1));
	break;
      case 2:/*High-pass*/
        printf("Doing LP-HP transformation...\n");
	item->normalization=warp(get_real(thpf2));
	tt=item->Ps.cte/item->Es.cte*item->Ps.a[0]/item->Es.a[0];
        tf=item->Fs.cte/item->Es.cte*item->Fs.a[item->px]/item->Es.a[0];
	InvertRoots(&item->Es,&item->rek);
	BuildPolynomial(item->Es.grau,1);
	memcpy(&item->Es,&x,sizeof(polynomial));
	memcpy(&item->rek,&zt,sizeof(roots));
	InvertRoots(&item->Ps,&item->rpk);
	BuildPolynomial(item->Ps.grau,tt);
	temp=item->Es.grau-item->Ps.grau;
	for (i=1; i<=temp; i++) {
	  MultS();
	  zt.re[x.grau]=0.0;
	  zt.im[x.grau]=0.0;
	}
	memcpy(&item->Ps,&x,sizeof(polynomial));
	memcpy(&item->rpk,&zt,sizeof(roots));
        InvertRoots(&item->Fs,&item->rfk);
	BuildPolynomial(item->Fs.grau,tf);
	memcpy(&item->Fs,&x,sizeof(polynomial));
	memcpy(&item->rfk,&zt,sizeof(roots));
	break;
      case 3:/*Band-pass*/
        printf("Doing LP-BP transformation...\n");
	tn=sqrtl(warp(get_real(tbpf2))*warp(get_real(tbpf3)));
	item->normalization=tn;
	B=(warp(get_real(tbpf3))-warp(get_real(tbpf2)))/tn;
	tt=item->Ps.cte/item->Es.cte;
	temp=item->Es.grau-item->Ps.grau;
	LpBpRoots(&item->Es,&item->rek,B);
	BuildPolynomial(2*item->Es.grau,1);
	memcpy(&item->rek,&zt,sizeof(roots));
	memcpy(&item->Es,&x,sizeof(polynomial));
	LpBpRoots(&item->Ps,&item->rpk,B);
	BuildPolynomial(2*item->Ps.grau,tt);
	for (i=1; i<=temp; i++) {
	  MultS();
	  MultC(B);
	  zt.re[x.grau]=0.0;
	  zt.im[x.grau]=0.0;
	}
	memcpy(&item->Ps,&x,sizeof(polynomial));
	memcpy(&item->rpk,&zt,sizeof(roots));
        LpBpRoots(&item->Fs,&item->rfk,B);
	BuildPolynomial(2*item->Fs.grau,1);
	memcpy(&item->rfk,&zt,sizeof(roots));
	memcpy(&item->Fs,&x,sizeof(polynomial));
        break;
      case 4:/*Band-reject*/;
        printf("Doing LP-BR transformation...\n");
	tn=sqrtl(warp(get_real(tbrf1))*warp(get_real(tbrf4)));
	item->normalization=tn;
	B=(warp(get_real(tbrf4))-warp(get_real(tbrf1)))/tn;
	tt=item->Ps.cte/item->Es.cte*item->Ps.a[0]/item->Es.a[0];
        tf=item->Fs.cte/item->Es.cte*item->Fs.a[item->px]/item->Es.a[0];
        for (i=1; i<=item->px; i++) tf*=B;
	temp=item->Es.grau-item->Ps.grau;
	InvertRoots(&item->Es,&item->rek);
	memcpy(&item->rek,&zt,sizeof(roots));
	LpBpRoots(&item->Es,&item->rek,B);
	memcpy(&item->rek,&zt,sizeof(roots));
	BuildPolynomial(2*item->Es.grau,1);
	memcpy(&item->rek,&zt,sizeof(roots));
	memcpy(&item->Es,&x,sizeof(polynomial));
	InvertRoots(&item->Ps,&item->rpk);
	memcpy(&item->rpk,&zt,sizeof(roots));
	LpBpRoots(&item->Ps,&item->rpk,B);
	for (i=1; i<=temp; i++) {
	  zt.re[2*item->Ps.grau+2*i-1]=0.0;
	  zt.im[2*item->Ps.grau+2*i-1]=1.0;
	  zt.re[2*item->Ps.grau+2*i]=0.0;
	  zt.im[2*item->Ps.grau+2*i]=-1.0;
	}
	BuildPolynomial(item->Es.grau,tt);
	memcpy(&item->Ps,&x,sizeof(polynomial));
	memcpy(&item->rpk,&zt,sizeof(roots));
        InvertRoots(&item->Fs,&item->rfk);
	memcpy(&item->rfk,&zt,sizeof(roots));
	LpBpRoots(&item->Fs,&item->rfk,B);
        for (i=1; i<=item->px; i++) {
          zt.re[item->Fs.grau*2+i]=0.0;
          zt.im[item->Fs.grau*2+i]=0.0;
        }
	memcpy(&item->rfk,&zt,sizeof(roots));
	BuildPolynomial(2*item->Fs.grau+item->px,tf);
	memcpy(&item->rfk,&zt,sizeof(roots));
	memcpy(&item->Fs,&x,sizeof(polynomial));
    }
    if (!(RADS)) item->normalization*=(2*M_PI);
    if (BILINEAR(inuse)) {
      printf("Doing bilinear transformation...\n");
      temp=item->Es.grau-item->Ps.grau;
      BilinearRoots(&item->Es,&item->rek);
      BuildPolynomial(item->Es.grau,1);
      memcpy(&item->rek,&zt,sizeof(roots));
      memcpy(&item->Ez,&x,sizeof(polynomial));
      BilinearRoots(&item->Ps,&item->rpk);
      for (i=1; i<=temp; i++) {
	zt.re[item->Ps.grau+i]=-1.0;
	zt.im[item->Ps.grau+i]=0.0;
      }
      BuildPolynomial(item->Es.grau,1);
      /* The multiplying constant in Pz(z) is Ps(2/T)/Es(2/T) */
      tt=2*item->sampling/item->normalization;
      a1=item->Ps.a[item->Ps.grau];
      for (i=item->Ps.grau-1; i>=0; i--) a1=a1*tt+item->Ps.a[i];
      b1=item->Es.a[item->Es.grau];
      for (i=item->Es.grau-1; i>=0; i--) b1=b1*tt+item->Es.a[i];
      c1=item->Fs.a[item->Fs.grau];
      for (i=item->Fs.grau-1; i>=0; i--) c1=c1*tt+item->Fs.a[i];
      MultC(item->Ps.cte*a1/b1);
      memcpy(&item->rpk,&zt,sizeof(roots));
      memcpy(&item->Pz,&x,sizeof(polynomial));
      BilinearRoots(&item->Fs,&item->rfk);
      BuildPolynomial(item->Fs.grau,1);
      MultC(item->Fs.cte*c1/b1);
      memcpy(&item->rfk,&zt,sizeof(roots));
      memcpy(&item->Fz,&x,sizeof(polynomial));
    }
    else if (LDI(inuse)) {
      printf("Doing LDI transformation...\n");
      /* Evaluating P(s)/E(s) and F(s)/E(s) at s=2T/2 for gain adjust */
      a1=1.0;
      a2=0.0;
      b1=1.0;
      b2=0.0;
      c1=1.0;
      c2=0.0;
      w=2*item->sampling/item->normalization;
      for (i=item->Ps.grau; i>0; i--) {
        a1=Cmult(a1,a2,-item->rpk.re[i],w-item->rpk.im[i]);
        a2=Imag;
      }
      for (i=item->Es.grau; i>0; i--) {
        b1=Cmult(b1,b2,-item->rek.re[i],w-item->rek.im[i]);
        b2=Imag;
      }
      for (i=item->Fs.grau; i>0; i--) {
        c1=Cmult(c1,c2,-item->rfk.re[i],w-item->rfk.im[i]);
        c2=Imag;
      }
      tt=item->Ps.cte/item->Es.cte*sqrtl((a1*a1+a2*a2)/(b1*b1+b2*b2));
      tf=item->Fs.cte/item->Es.cte*sqrtl((c1*c1+c2*c2)/(b1*b1+b2*b2));
      LDIRoots(&item->Es,&item->rek);
      BuildPolynomial(item->Es.grau,1);
      memcpy(&item->rek,&zt,sizeof(roots));
      memcpy(&item->Ez,&x,sizeof(polynomial));
      LDIRoots(&item->Ps,&item->rpk);
      BuildPolynomial(item->Ps.grau,1);
      memcpy(&item->rpk,&zt,sizeof(roots));
      memcpy(&item->Pz,&x,sizeof(polynomial));
      LDIRoots(&item->Fs,&item->rfk);
      BuildPolynomial(item->Fs.grau,1);
      memcpy(&item->rfk,&zt,sizeof(roots));
      memcpy(&item->Fz,&x,sizeof(polynomial));
      /* |Pz(-1)/Ez(-1)|=|Ps(j2/T)/Es(j2/T)|
         |Fz(-1)/Ez(-1)|=|Fs(j2/T)/Es(j2/T)| */
      a1=1.0;
      a2=0.0;
      b1=1.0;
      b2=0.0;
      c1=1.0;
      c2=0.0;
      z1=-1.0;
      for (i=item->Pz.grau; i>0; i--) {
        a1=Cmult(a1,a2,z1-item->rpk.re[i],-item->rpk.im[i]);
        a2=Imag;
      }
      for (i=item->Ez.grau; i>0; i--) {
        b1=Cmult(b1,b2,z1-item->rek.re[i],-item->rek.im[i]);
        b2=Imag;
      }
      for (i=item->Fz.grau; i>0; i--) {
        c1=Cmult(c1,c2,z1-item->rfk.re[i],-item->rfk.im[i]);
        c2=Imag;
      }
      item->Pz.cte=tt/sqrtl((a1*a1+a2*a2)/(b1*b1+b2*b2));
      item->Fz.cte=tf*sqrtl((b1*b1+b2*b2)/(c1*c1+c2*c2));
    }
  }
  printf("Preparing cascade design...\n");
  item->np=DISCRETE(inuse)?item->Ez.grau:item->Es.grau;
  item->nz=DISCRETE(inuse)?item->Pz.grau:item->Ps.grau;
  SortRoots(&item->rpk,item->nz,2);
  SortRoots(&item->rek,item->np,2);
  SortRoots(&item->rfk,DISCRETE(inuse)?item->Fz.grau:item->Fs.grau,2);
  item->nb=(item->np+1)/2;
  tt=powl(DISCRETE(inuse)?item->Pz.cte:item->Ps.cte,1.0/(ldouble)item->nb);
  for (i=1; i<=item->nb; i++) {
    item->biquad[i].pole[0]=0;
    item->biquad[i].pole[1]=0;
    item->biquad[i].zero[0]=0;
    item->biquad[i].zero[1]=0;
    item->biquad[i].gain=tt;
  }
  printf("Design complete\n");
  frequency_valid=false;
  RedrawFrequency();
  if (!filter[inuse].valid) printf("* The specified design was not possible\n");
}

int flimx(ldouble x)
{
  ldouble t;

  if (LOG) t=aw*logl(x)+bw;
  else t=aw*x+bw;
  if (t>fxmax) return fxmax;
  if (t<fxmin) return fxmin;
  return((int)floorl(t+0.5));
}

int flimy(ldouble y,ldouble a,ldouble b)
{
  ldouble t;

  t=a*y+b;
  if (t>fymax) return fymax;
  if (t<fymin) return fymin;
  return((int)floorl(t+0.5));
}

void DrawScales(ldouble x1,ldouble x2,ldouble y1,ldouble y2,
  int xmin, int xmax, int ymin, int ymax,
  boolean xlog, boolean grid)
{
  ldouble ax,bx,ay,by,t1,t2;
  int i;
  char STR1[256];
  char txt[100];

  ay=(ymax-ymin)/(y1-y2);
  by=ymax-ay*y1;
  if (!xlog) {
    ax=(xmax-xmin)/(x2-x1);
    bx=xmin-ax*x1;
  }
  else {
    ax=(xmax-xmin)/logl(x2/x1);
    bx=xmin-ax*logl(x1);
  }
  if (grid && x2>x1 && y2>y1) {
    setlinestyle(DOTTED_LINE,0,NORM_WIDTH);
    setcolor(c_line);
    if (xlog&&x2-x1>x1)
      t1=x1;
    else
      t1=x2-x1;
    t1=exp(logl(10.0)*floorl(logl(t1)/logl(10.0)-0.499999+0.5));
    t2=floorl(x1/t1+1)*t1;
    while (t2<x2) {
      if (!xlog) {
	i=(int)floorl(ax*t2+bx+0.5);
	line(i,ymin,i,ymax);
	t2+=t1;
	continue;
      }
      if ((int)floorl(t2/t1+0.5)==10) {
	t1=10*t1;
	setcolor(c_limit);
      }
      i=(int)floorl(ax*logl(t2)+bx+0.5);
      line(i,ymin,i,ymax);
      t2+=t1;
      setcolor(c_line);
    }
    t1=y2-y1;
    t1=exp(logl(10.0)*floorl(logl(t1)/logl(10.0)));
    t2=floorl(y1/t1+1)*t1;
    while (t2<y2) {
      i=(int)floorl(ay*t2+by+0.5);
      line(xmin,i,xmax,i);
      t2+=t1;
    }
  }
  setlinestyle(SOLID_LINE,0,NORM_WIDTH);
  setcolor(c_text);
  line(0,ymax,xmax,ymax);
  line(xmin,ymin,xmin,getmaxy());
  sprintf(txt,"%5.1Lf",y2);
  outtextxy(0,ymin,txt);
  sprintf(txt,"%5.1Lf",y1);
  outtextxy(0,ymax-8,txt);
  sprintf(txt,"%8.3Lf",x1);
  while (txt[0]==' ') {
    strcpy(STR1,txt+1);
    strcpy(txt,STR1);
  }
  outtextxy(xmin+2,ymax+2,txt);
  sprintf(txt,"%8.3Lf",x2);
  outtextxy(xmax-64,ymax+2,txt);
}

/* Callback Procedures */

void NotifyFrequency(Xv_opaque obj)
{
  int x1,x2,y1,y2,ix,j,k,xa,di;
  ldouble t,f,w,cte,fatord,a1,a2,da2,b1,b2,db2,sr,si,wt,z1,z2,tg;
  design *WITH;
  polynomial *DEN;
  roots *POLE;

  /* Notify handler for cfrequency */
  /* Mapping */
  fxmin=50; fymin=3; fxmax=get_dx(cfrequency)-5; fymax=get_dy(cfrequency)-11;
  ag=(fymax-fymin)/(get_real(tgmin)-get_real(tgmax));
  bg=fymax-ag*get_real(tgmin);
  ad=(fymax-fymin)/(get_real(tdmin)-get_real(tdmax));
  bd=fymax-ad*get_real(tdmin);
  ap=(fymin-fymax)/360.0;
  bp=fymax+ap*180;
  ah=(ldouble)(fxmax-fxmin)/get_int(tsegmf);
  bh=fxmin;
  if (get_real(twmin)*get_real(twmax)<=0) slog->v.ssetting.sel_setting=1;
  if (LOG) {
    dw=powl(get_real(twmax)/get_real(twmin),1.0/get_int(tsegmf));
    aw=(fxmax-fxmin)/logl(get_real(twmax)/get_real(twmin));
    bw=fxmax-aw*logl(get_real(twmax));
  }
  else {
    dw=(get_real(twmax)-get_real(twmin))/get_int(tsegmf);
    aw=(fxmax-fxmin)/(get_real(twmax)-get_real(twmin));
    bw=fxmax-aw*get_real(twmax);
  }
  /* Limits */
  setfillstyle(SOLID_FILL,c_background);
  bar(0,0,get_dx(cfrequency),get_dy(cfrequency));
  if (((get_sel(splot))&2)==2) {
    setfillstyle(LTSLASH_FILL,c_barriers);
    switch (get_sel(stype)) {
      case 1:
	x1=fxmin;
	y1=flimy(-get_real(tamax),ag,bg);
	x2=flimx(get_real(tlpf1));
	y2=fymax;
	bar(x1,y1,x2,y2);
	y1=fymin;
	x2=flimx(get_real(tlpf2));
	y2=flimy(0,ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(tlpf2));
	y1=fymin;
	x2=fxmax;
	y2=flimy(-get_real(tamin),ag,bg);
	bar(x1,y1,x2,y2);
	break;
      case 2:
	x1=fxmin;
	y1=fymin;
	x2=flimx(get_real(thpf1));
	y2=flimy(-get_real(tamin),ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(thpf1));
	y1=fymin;
	x2=fxmax;
	y2=flimy(0,ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(thpf2));
	y1=flimy(-get_real(tamax),ag,bg);
	x2=fxmax;
	y2=fymax;
	bar(x1,y1,x2,y2);
	break;
      case 3:
	x1=fxmin;
	y1=fymin;
	x2=flimx(get_real(tbpf1));
	y2=flimy(-get_real(tamin),ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(tbpf1));
	y1=fymin;
	x2=flimx(get_real(tbpf4));
	y2=flimy(0,ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(tbpf2));
	y1=flimy(-get_real(tamax),ag,bg);
	x2=flimx(get_real(tbpf3));
	y2=fymax;
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(tbpf4));
	y1=fymin;
	x2=fxmax;
	y2=flimy(-get_real(tamin),ag,bg);
	bar(x1,y1,x2,y2);
	break;
      case 4:
	x1=fxmin;
	y1=flimy(-get_real(tamax),ag,bg);
	x2=flimx(get_real(tbrf1));
	y2=fymax;
	bar(x1,y1,x2,y2);
	x1=fxmin;
	y1=fymin;
	x2=fxmax;
	y2=flimy(0,ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(tbrf2));
	y1=flimy(0,ag,bg);
	x2=flimx(get_real(tbrf3));
	y2=flimy(-get_real(tamin),ag,bg);
	bar(x1,y1,x2,y2);
	x1=flimx(get_real(tbrf4));
	y1=flimy(-get_real(tamax),ag,bg);
	x2=fxmax;
	y2=fymax;
	bar(x1,y1,x2,y2);
    }
  }
  DrawScales(get_real(twmin),get_real(twmax),get_real(tgmin),get_real(tgmax),
  fxmin,fxmax,fymin,fymax,LOG,((get_sel(splot))&1)==1);
  outtextxy(fxmax-32,fymax-9,sHertz->v.ssetting.item_setting[sHertz->v.ssetting.sel_setting-1]);
  if (!frequency_valid) ultpt=-1;
  fcolcsr=-100; fycsr=-100;
  /* Frequency resposes */
  if (filter[inuse].valid) {
    f=get_real(twmin);
    ix=0;
    do {
      if (ix>ultpt) {
	for (di=0; di<=ndesigns; di++) if (filter[di].valid) {
	  WITH=&(filter[di]);
          if (PLOTK) {
            if (DISCRETE(di)) DEN=&WITH->Fz;
            else DEN=&WITH->Fs;
            POLE=&WITH->rfk;
          }
          else {
            if (DISCRETE(di)) DEN=&WITH->Ez;
            else DEN=&WITH->Es;
            POLE=&WITH->rek;
          }
	  if (DISCRETE(di)) fatord=1; else fatord=WITH->normalization;
	  if (RADS)
	    w=f/fatord;
	  else
	    w=2*M_PI*f/fatord;
	  if (DISCRETE(di)) {
            cte=WITH->Pz.cte/DEN->cte;
            wt=w/WITH->sampling;
            z1=cosl(wt);
            z2=sinl(wt);
            {
              /* Tg is computed for each root as:
                 -T((z1-re)*z1+(z2-im)*z2)/((z1-re)^2+(z2-im)^2) */
              a1=1.0;
	      a2=0.0;
	      b1=1.0;
	      b2=0.0;
              tg=0.0;
              for (j=WITH->Pz.grau; j>0; j--) {
                a1=Cmult(a1,a2,z1-WITH->rpk.re[j],z2-WITH->rpk.im[j]);
                a2=Imag;
                da2=z1-WITH->rpk.re[j];
                db2=z2-WITH->rpk.im[j];
                tg-=(da2*z1+db2*z2)/(da2*da2+db2*db2);
              }
              for (j=DEN->grau; j>0; j--) {
                b1=Cmult(b1,b2,z1-POLE->re[j],z2-POLE->im[j]);
                b2=Imag;
                da2=z1-POLE->re[j];
                db2=z2-POLE->im[j];
                tg+=(da2*z1+db2*z2)/(da2*da2+db2*db2);
              }
            }
          }
          else {
            cte=WITH->Ps.cte/DEN->cte;
            {
              /* Tg is computed for each root as 1/(1+((w-im)/re)^2)/re */
              a1=1.0;
	      a2=0.0;
	      b1=1.0;
	      b2=0.0;
              tg=0.0;
              for (j=WITH->Ps.grau; j>0; j--) {
                a1=Cmult(a1,a2,-WITH->rpk.re[j],w-WITH->rpk.im[j]);
                a2=Imag;
                /* Never true */
                if (fabsl(WITH->rpk.re[j])>tolm) {
                  t=(w-WITH->rpk.im[j])/WITH->rpk.re[j];
                  tg+=1/(1+t*t)/WITH->rpk.re[j];
                }
              }
              for (j=DEN->grau; j>0; j--) {
                b1=Cmult(b1,b2,-POLE->re[j],w-POLE->im[j]);
                b2=Imag;
                /* Always true */
                if (fabsl(POLE->re[j])>tolm) {
                  t=(w-POLE->im[j])/POLE->re[j];
                  tg-=1/(1+t*t)/POLE->re[j];
                }
              }
            }
          }
	  sr=cte*Cdiv(a1,a2,b1,b2);
	  si=cte*Imag;
	  WITH->Ang[ix]=atan2l(si,sr)*180/M_PI;
	  WITH->Gan[ix]=10*log10l(sr*sr+si*si);
	  if (DISCRETE(di)) WITH->Tg[ix]=tg/WITH->sampling;
          else WITH->Tg[ix]=tg/fatord;
	}
	Frq[ix]=f;
      }
      j=(long)floorl(ix*ah+bh+0.5);
      for (di=ndesigns; di>=0; di--) if (filter[di].valid) {
	WITH=&(filter[di]);
	k=flimy(WITH->Gan[ix],ag,bg);
        setcolor(cor[di]);
	if (ix>0) {
	  if (BYTYPE) setcolor(c_gain);
	  line(xa,WITH->ga,j,k);
	}
	WITH->ga=k;
	if (PHASE) {
	  k=flimy(WITH->Ang[ix],ap,bp);
	  if (ix>0) {
	    if (BYTYPE) setcolor(c_phase);
	    line(xa,WITH->fa,j,k);
	  }
	  WITH->fa=k;
	}
	if (DELAY) {
	  k=flimy(WITH->Tg[ix],ad,bd);
	  if (ix>0) {
	    if (BYTYPE) setcolor(c_delay);
	    line(xa,WITH->ta,j,k);
	  }
	  WITH->ta=k;
	}
      }
      xa=j;
      if (LOG)
	f*=dw;
      else
	f+=dw;
      ix++;
    } while (ix<=get_int(tsegmf));
    ix=get_int(tsegmf);
    ultpt=ix;
    frequency_valid=true;
  }
}

void EventsFrequency(Xv_opaque obj)
{
  /* Event handler for cfrequency */
  static int xi=0, yi=0, xf=0, yf=0;
  static double xmin0=0.2,ymin0=-80,xmax0=5,ymax0=10;
  static boolean selecao=false;
  ldouble t;
  ldouble TEMP;
  char txt[256];

  if (selecao) {
    setwritemode(XOR_PUT);
    setcolor(c_cursor);
    if (ie_code==LOC_DRAG) {
      rectangle(xi,yi,xf,yf);
      xf=ie_locx;
      yf=ie_locy;
      rectangle(xi,yi,xf,yf);
      return;
    }
    if (ie_shiftcode==0) {
      xmin0=get_real(twmin);
      xmax0=get_real(twmax);
      ymin0=get_real(tgmin);
      ymax0=get_real(tgmax);
      selecao=false;
      rectangle(xi,yi,xf,yf);
      if (xi>=xf||yi>=yf) return;
      set_real(twmin,(xi-bw)/aw);
      if (LOG)
	set_real(twmin,exp(get_real(twmin)));
      set_real(twmax,(xf-bw)/aw);
      if (LOG)
	set_real(twmax,exp(get_real(twmax)));
      set_real(tgmin,(yf-bg)/ag);
      set_real(tgmax,(yi-bg)/ag);
    }
    setwritemode(COPY_PUT);
    goto Recalcular;
  }

  if (ie_code<256) ie_code=toupper(ie_code);
  switch (ie_code) {

    case MS_MIDDLE:
    case LOC_DRAG:
    case ' ':
      fcsr=(int)floorl((ie_locx-bh)/ah+0.5);
      if (fcsr<0)
	fcsr=0;
      if (fcsr>ultpt)
	fcsr=ultpt;
      goto Cursor;

    case 'L':
      if (LOG)
	set_sel(slog,1);
      else
	set_sel(slog,2);
      goto Recalcular;

    case 'R':
      if (LOG) {
	TEMP=get_real(twmax)/get_real(twmin);
	set_real(twmax,get_real(twmin)*TEMP*TEMP);
      }
      else
	set_real(twmax,get_real(twmin)+(get_real(twmax)-get_real(twmin))*2);
	goto Recalcular;

    case 'A':
      if (LOG)
	set_real(twmax,get_real(twmin)*sqrtl(get_real(twmax)/get_real(twmin)));
      else
	set_real(twmax,get_real(twmin)+(get_real(twmax)-get_real(twmin))/2);
      goto Recalcular;

    case '>':
    case '.':
      if (LOG) {
	t=sqrtl(sqrtl(get_real(twmax)/get_real(twmin)));
	twmin->v.stextfield.panel_real*=t;
	twmax->v.stextfield.panel_real*=t;
      }
      else {
	t=(get_real(twmax)-get_real(twmin))/4;
	twmin->v.stextfield.panel_real+=t;
	twmax->v.stextfield.panel_real+=t;
      }
      goto Recalcular;

    case '<':
    case ',':
      if (LOG) {
	t=sqrtl(sqrtl(get_real(twmax)/get_real(twmin)));
	twmin->v.stextfield.panel_real/=t;
	twmax->v.stextfield.panel_real/=t;
      }
      else {
	t=(get_real(twmax)-get_real(twmin))/4;
	twmin->v.stextfield.panel_real-=t;
	twmax->v.stextfield.panel_real-=t;
      }
      goto Recalcular;

    case 'G':
      set_sel(splot,get_sel(splot) ^ 1);
      goto Retracar;

    case 'M':
      set_sel(splot,get_sel(splot) ^ 2);
      goto Retracar;

    case 'P':
      set_sel(splot,get_sel(splot) ^ 4);
      goto Retracar;

    case 'D':
      set_sel(splot,get_sel(splot) ^ 8);
      goto Retracar;

    case KLEFTARROW:
      if (fcsr>=1)
	fcsr--;
      goto Cursor;

    case KRIGHTARROW:
      if (fcsr<ultpt)
	fcsr++;
      goto Cursor;

    case KUPARROW:
      t=(get_real(tgmax)-get_real(tgmin))/4;
      tgmin->v.stextfield.panel_real+=t;
      tgmax->v.stextfield.panel_real+=t;
      goto Retracar;

    case KDOWNARROW:
      t=(get_real(tgmax)-get_real(tgmin))/4;
      tgmin->v.stextfield.panel_real-=t;
      tgmax->v.stextfield.panel_real-=t;
      goto Retracar;

    case '-':
      set_real(tgmax,2*get_real(tgmax)-get_real(tgmin));
      goto Retracar;

    case '+':
      set_real(tgmax,(get_real(tgmax)+get_real(tgmin))/2);
      goto Retracar;

    case MS_LEFT:
      xi=ie_locx;
      yi=ie_locy;
      xf=xi;
      yf=yi;
      selecao=true;
      return;

    case 'Z':
      set_real(twmin,xmin0);
      set_real(twmax,xmax0);
      set_real(tgmin,ymin0);
      set_real(tgmax,ymax0);
      goto Recalcular;

    default: return;
  }
Cursor:
  if (!frequency_valid) return;
  setwritemode(XOR_PUT);
  setcolor(c_cursor);
  line(fcolcsr,fymin,fcolcsr,fymax);
  setcolor(c_marker);
  rectangle(fcolcsr-4,fycsr-4,fcolcsr+4,fycsr+4);
  fycsr=flimy(filter[inuse].Gan[fcsr],ag,bg);
  fcolcsr=(int)(ah*fcsr+bh);
  setcolor(c_cursor);
  line(fcolcsr,fymin,fcolcsr,fymax);
  setcolor(c_marker);
  rectangle(fcolcsr-4,fycsr-4,fcolcsr+4,fycsr+4);
  setwritemode(COPY_PUT);
  setfillstyle(SOLID_FILL,c_background);
  bar(fxmin+4,fymax-39,fxmin+81,fymax-4);
  setcolor(c_text);
  rectangle(fxmin+3,fymax-40,fxmin+82,fymax-3);
  settextstyle(SMALL_FONT,HORIZ_DIR,4);
  sprintf(txt,"F:%11.5Lf",Frq[fcsr]);
  outtextxy(fxmin+6,fymax-41,txt);
  sprintf(txt,"G:%11.5Lf",filter[inuse].Gan[fcsr]);
  outtextxy(fxmin+6,fymax-41+9,txt);
  sprintf(txt,"P:%11.5Lf",filter[inuse].Ang[fcsr]);
  outtextxy(fxmin+6,fymax-41+18,txt);
  sprintf(txt,"D:%11.5Lf",filter[inuse].Tg[fcsr]);
  outtextxy(fxmin+6,fymax-41+27,txt);
  return;
Recalcular:
  frequency_valid=false;
Retracar:
  NotifyFrequency(NULL);
}

void RedrawFrequency(void)
{
  while (active_w!=ffrequency) close_window(active_w);
  if (active_w==ffrequency) NotifyFrequency(NULL);
}

int rlimx(ldouble x)
{
  ldouble t;

  t=ax*x+bx;
  if (t>rxmax)
    return rxmax;
  else if (t<rxmin)
    return rxmin;
  else
    return ((long)floorl(t+0.5));
}

int rlimy(ldouble y)
{
  ldouble t;

  t=ay*y+by;
  if (t>rymax)
    return rymax;
  else if (t<rymin)
    return rymin;
  else
    return ((long)floorl(t+0.5));
}

void PlotRoots(roots *z, int n, boolean polo, ldouble norm)
{
  int i,j,x,y,order;
  char txt[3];

  settextstyle(SMALL_FONT,HORIZ_DIR,4);
  for (i=1; i<=n; i++) {
    x=rlimx(z->re[i]*norm);
    y=rlimy(z->im[i]*norm);
    if (polo) {
      line(x-2,y-2,x+2,y+2);
      line(x-2,y+2,x+2,y-2);
    } else
      circle(x,y,4);
    order=1;
    for (j=1; j<=n; j++) if (j!=i)
      if (fabsl(z->re[i]-z->re[j])<tolm && fabsl(z->im[i]-z->im[j])<tolm) order++;
    if (order>1) {
      sprintf(txt,"%d",order);
      outtextxy(x+5,y+2,txt);
    }
  }
}

void NotifyRoots(Xv_opaque obj)
{
  /* Notify handler for croots */
  int nz,di;
  ldouble norm;

  rxmin=50; rymin=3; rymax=get_dy(croots)-11; rxmax=rymax-rymin+rxmin;
  xcsr=ycsr=-100;
  setfillstyle(SOLID_FILL,c_background);
  bar(0,0,get_dx(croots)-2,get_dy(croots)-2);
  ay=(rymax-rymin)/(-tdelta);
  by=rymax-ay*tymin;
  ax=(rxmax-rxmin)/tdelta;
  bx=rxmin-ax*txmin;
  DrawScales(txmin,txmin+tdelta,tymin,tymin+tdelta,
    rxmin,rxmax,rymin,rymax,false,((get_sel(splot))&1)==1);
  for (di=0; di<=ndesigns; di++) if (filter[di].valid) {
    setcolor(c_barriers);
    setlinestyle(DOTTED_LINE,0,1);
    if (DISCRETE(di)) circle((int)floorl(bx+0.5),(int)floorl(by+0.5),
         (int)floorl(ax+0.5));
    else {
      line(rxmin,rlimy(0),rxmax,rlimy(0));
      line(rlimx(0),rymin,rlimx(0),rymax);
    }
    setlinestyle(SOLID_LINE,0,1);
    setcolor(cor[di]);
    if (DISCRETE(di)) {
      nz=PLOTK?filter[di].Fz.grau:filter[di].Ez.grau;
      norm=1;
    }
    else {
      nz=PLOTK?filter[di].Fs.grau:filter[di].Es.grau;
      norm=filter[di].normalization;
    }
    PlotRoots(PLOTK?&filter[di].rfk:&filter[di].rek,nz,true,norm);
    if (DISCRETE(di)) nz=filter[di].Pz.grau;
    else nz=filter[di].Ps.grau;
    PlotRoots(&(filter[di].rpk),nz,false,norm);
  }
}

ldouble rnorm,rx1,ry1,rx,ry,rdist;
int rpolos,ratual,ix;

void Testar(int i, int n, roots *raizes, boolean saopolos)
{
  ldouble teste;
  int j;

  for (j=1; j<=n; j++) {
    teste=fabsl(rx1-raizes->re[j]*rnorm)+fabsl(ry1-raizes->im[j]*rnorm);
    if (teste<rdist) {
      ratual=i;
      rdist=teste;
      rpolos=saopolos;
      rx=raizes->re[j]*rnorm;
      ry=raizes->im[j]*rnorm;
      ix=j;
    }
  }
}

void EventsRoots(Xv_opaque obj)
{
  /* Event handler for croots */

  static int xi=0,yi=0,xf=0,yf=0;
  static boolean selecao=false;
  char txt[50];
  ldouble w;
  int i;
  design *WITH;
  boolean some;

  if (selecao) {
    setwritemode(XOR_PUT);
    setcolor(c_cursor);
    if (ie_code==LOC_DRAG) {
      rectangle(xi,yi,xf,yf);
      yf=ie_locy;
      xf=xi+floorl((yi-yf)*ax/ay+0.5);
      rectangle(xi,yi,xf,yf);
      return;
    }
    else {
      selecao=false;
      rectangle(xi,yi,xf,yf);
      setwritemode(COPY_PUT);
      if (xi>=xf || yi>=yf)
	return;
      txmin=(xi-bx)/ax;
      tymin=(yf-by)/ay;
      tdelta=(yi-yf)/ay;
      goto Replotar;
    }
  }
  switch (ie_code) {

    case MS_LEFT:
      xi=ie_locx;
      yi=ie_locy;
      xf=xi;
      yf=yi;
      selecao=true;
      return;

    case KUPARROW:
      tymin+=tdelta/4;
      break;

    case KDOWNARROW:
      tymin-=tdelta/4;
      break;

    case KRIGHTARROW:
      txmin+=tdelta/4;
      break;

    case KLEFTARROW:
      txmin-=tdelta/4;
      break;

    case '-':
      tymin-=tdelta/2;
      txmin-=tdelta/2;
      tdelta*=2;
      break;

    case '+':
      tymin+=tdelta/4;
      txmin+=tdelta/4;
      tdelta/=2;
      break;

    case LOC_DRAG:
    case MS_MIDDLE:
    case ' ':
      rx1=(ie_locx-bx)/ax;
      ry1=(ie_locy-by)/ay;
      rdist=1e38;
      some=false;
      for (i=0; i<=ndesigns; i++) if (filter[i].valid) {
        some=true;
	WITH=&filter[i];
        if (DISCRETE(i)) {
          rnorm=1.0;
	  Testar(i,WITH->Ez.grau,PLOTK?&WITH->rfk:&WITH->rek,true);
	  Testar(i,WITH->Pz.grau,&WITH->rpk,false);
        }
        else {
          rnorm=WITH->normalization;
          Testar(i,WITH->Es.grau,PLOTK?&WITH->rfk:&WITH->rek,true);
	  Testar(i,WITH->Ps.grau,&WITH->rpk,false);
        }
      }
      if (!some) return;
      setwritemode(XOR_PUT);
      setcolor(cor[1]);
      rectangle(xcsr-5,ycsr-5,xcsr+5,ycsr+5);
      xcsr=rlimx(rx); ycsr=rlimy(ry);
      rectangle(xcsr-5,ycsr-5,xcsr+5,ycsr+5);
      setwritemode(COPY_PUT);
      setfillstyle(SOLID_FILL,c_background);
      bar(rxmax+3,rymin+1,rxmax+91,rymin+55);
      setcolor(c_text);
      rectangle(rxmax+2,rymin,rxmax+92,rymin+56);
      settextstyle(SMALL_FONT,HORIZ_DIR,4);
      outtextxy(rxmax+5,rymin,filter[ratual].title);
      sprintf(txt,"%s(%d):",rpolos?"Pole":"Zero",ix);
      outtextxy(rxmax+5,rymin+9,txt);
      sprintf(txt,"Re:%10Lg",rx);
      outtextxy(rxmax+5,rymin+18,txt);
      sprintf(txt,"Im:%10Lg",ry);
      outtextxy(rxmax+5,rymin+27,txt);
      w=sqrtl(rx*rx+ry*ry);
      sprintf(txt,"w: %10Lg",w);
      outtextxy(rxmax+5,rymin+36,txt);
      if (fabsl(rx)>tolm)
	sprintf(txt,"Q: %10Lg",-0.5*w/rx);
      else
	strcpy(txt,"Q: infinite");
      outtextxy(rxmax+5,rymin+45,txt);
      return;
   default: return;
   }
  Replotar:
   NotifyRoots(NULL);
}

void InvalidateDesign(Xv_opaque obj)
{
  filter[inuse].valid=0;
  filter[inuse].realized=0;
  frequency_valid=0;
  printf("Design cleared\n");
}

void InvalidateFrequency(Xv_opaque obj)
{
  frequency_valid=0;
}

void ApplyParameters(Xv_opaque obj)
{
  /* Notify handler for bapplyparameters */
  RedrawFrequency();
}

void ProcessfHP(Xv_opaque obj)
{
  /* Notify handler for bapplyfhp */
  RedrawFrequency();
}

void ProcessfLP(Xv_opaque obj)
{
  /* Notify handler for bapplyflp */
  RedrawFrequency();
}

void Processfbr(Xv_opaque obj)
{
  /* Notify handler for bapplyfbr */
  RedrawFrequency();
}

void ProcessfBP(Xv_opaque obj)
{
  /* Notify handler for bapplyfBP */
  RedrawFrequency();
}

void ProcessPolynomial(Xv_opaque obj)
{
  /* Notify handler for spolynomial */
  set_sel(sinverse,0);
  set_sel(srational,0);
  update(sinverse);
  update(srational);
  InvalidateDesign(NULL);
}

void ProcessInverse(Xv_opaque obj)
{
  /* Notify handler for sinverse */
  set_sel(spolynomial,0);
  set_sel(srational,0);
  update(spolynomial);
  update(srational);
  InvalidateDesign(NULL);
}

void ProcessRational(Xv_opaque obj)
{
  /* Notify handler for srational */
  set_sel(spolynomial,0);
  set_sel(sinverse,0);
  update(spolynomial);
  update(sinverse);
  InvalidateDesign(NULL);
}


void OpenFrequency(Xv_opaque obj)
{
  /* Notify handler for stype */
  close_window(flplimits);
  close_window(fhplimits);
  close_window(fbplimits);
  close_window(fbrlimits);
  switch (get_sel(stype)) {
    case 1:open_window(flplimits); break;
    case 2:open_window(fhplimits); break;
    case 3:open_window(fbplimits); break;
    case 4:open_window(fbrlimits);
  }
  if (obj==stype) InvalidateDesign(NULL);
}

void SelectDesign(Xv_opaque obj)
{
  /* Notify handler for tnumber */
  design *WITH;

  inuse=get_int(tnumber)-1;
  WITH=&(filter[inuse]);
  set_sel(stype,WITH->type);
  set_sel(spolynomial,WITH->pol);
  set_sel(sinverse,WITH->inv);
  set_sel(srational,WITH->rat);
  set_int(torder,WITH->order);
  set_sel(sanadig,WITH->anadig);
  set_real(tsampling,WITH->sampling);
  set_real(tamax,WITH->Amax);
  set_real(tamin,WITH->Amin);
  set_value(ttitle,WITH->title);
  close_window(fapproximation);
  open_window(fapproximation);
}

void Npx(Xv_opaque obj)
{
  /* Notify handler for tpx */
  design* WITH;

  WITH=&filter[inuse];
  if ((get_int(tpx)&1)^(WITH->n&1)) {
    printf("Wrong parity in X(w) roots at 0\n");
    set_int(tpx,WITH->px);
    update(tpx);
  }
  else {
    WITH->px=get_int(tpx);
    FDefault(WITH->n, WITH->px, WITH->fx);
  }
}

void Npy(Xv_opaque obj)
{
  /* Notify handler for tpy */
  design* WITH;

  WITH=&filter[inuse];
  if ((get_int(tpy)&1)^(WITH->n&1)) {
    printf("Wrong parity in Y(w) roots at 0\n");
    set_int(tpy,WITH->py);
    update(tpy);
  }
  else {
    WITH->py=get_int(tpy);
    FDefault(WITH->n, WITH->py, WITH->fy);
  }
}

void Changefx(Xv_opaque obj)
{
  /* Notify handler for tfxto */
  ldouble at;

  filter[inuse].fx[get_int(tchangefx)]=get_real(tfxto);
  at=filter[inuse].epsilon*get_real(tfxto);
  set_real(tchangeAx,10*logl(1+at*at)/logl(10.0));
  update(tchangeAx);
}

void Ntchangefx(Xv_opaque obj)
{
  /* Notify handler for tchangefx*/

  set_real(tfxto,filter[inuse].fx[get_int(tchangefx)]);
  update(tfxto);
  Changefx(NULL);
}

void Changefy(Xv_opaque obj)
{
  /* Notify handler for tfyto */
  ldouble at;

  filter[inuse].fy[get_int(tchangefy)]=get_real(tfyto);
  if (get_real(tfyto)==0.0) at=1000;
  else {
    at=filter[inuse].epsilon*filter[inuse].alfa*filter[inuse].alfa/get_real(tfyto);
    at=10*logl(1+at*at)/logl(10.0);
  }
  set_real(tchangeAy,at);
  update(tchangeAy);
}

void Ntchangefy(Xv_opaque obj)
{
  /* Notify handler for tchangefy*/

  set_real(tfyto,filter[inuse].fy[get_int(tchangefy)]);
  update(tfyto);
  Changefy(NULL);
}

void ChangeAx(Xv_opaque obj)
{
  /* Notify handler for tchangeAx */
  ldouble temp;

  temp=sqrtl(powl(10.0,0.1*get_real(tchangeAx))-1)/filter[inuse].epsilon;
    if (filter[inuse].fx[get_int(tchangefx)]<0) temp=-temp;
  filter[inuse].fx[get_int(tchangefx)]=temp;
  set_real(tfxto,temp);
  update(tfxto);
}

void ChangeAy(Xv_opaque obj)
{
  /* Notify handler for tchangeAy */
  ldouble temp;

  if (get_real(tchangeAy)<1000)
    temp=filter[inuse].epsilon*filter[inuse].alfa*filter[inuse].alfa/
      sqrtl(powl(10.0,0.1*get_real(tchangeAy))-1);
  else temp=0.0;
    if (filter[inuse].fy[get_int(tchangefy)]<0) temp=-temp;
  filter[inuse].fy[get_int(tchangefy)]=temp;
  set_real(tfyto,temp);
  update(tfyto);
}

void ListExtremes(Xv_opaque obj)
{
  /* Notify handler for blistf */
  int i,m;
  ldouble at;
  design *WITH;
  char txt[50];

  WITH=&filter[inuse];
  m=(WITH->n-WITH->px)/2+1;
  printf("Extremes of X(w):\n");
  for (i=1; i<m; i++) {
    at=WITH->epsilon*WITH->fx[i];
    at=10*logl(1+at*at)/logl(10.0);
    printf("fx(%d)=%Lg (%Lg dB)\n",i,WITH->fx[i],at);
  }
  m=(WITH->n-WITH->py)/2+1;
  printf("Extremes of Y(w):\n");
  for (i=1; i<m; i++) {
    if (WITH->fy[i]==0.0) strcpy(txt,"infinity");
    else {
      at=WITH->epsilon*WITH->alfa*WITH->alfa/WITH->fy[i];
      at=10*logl(1+at*at)/logl(10.0);
      sprintf(txt,"%Lg dB",at);
    }
    printf("fy(%d)=%Lg (%s)\n",i,WITH->fy[i],txt);
  }
}

void Complete(Xv_opaque obj)
{
  /* Notify handler for bcomplete */
  CompleteDesign(&filter[inuse]);
}

void ApplyApprox(Xv_opaque obj)
{
  design *WITH;
  /* Notify handler for bapplyapprox */
  WITH=&(filter[inuse]);
  WITH->type=get_sel(stype);
  WITH->pol=get_sel(spolynomial);
  WITH->inv=get_sel(sinverse);
  WITH->rat=get_sel(srational);
  WITH->order=get_int(torder);
  WITH->anadig=get_sel(sanadig);
  WITH->sampling=get_real(tsampling);
  WITH->Amax=get_real(tamax);
  WITH->Amin=get_real(tamin);
  strcpy(WITH->title,get_value(ttitle));
  /* Obtaining parameters for the normalized low-pass prototype */
  switch (get_sel(spolynomial)) {
    case 0: /*Inverse or Rational */
      switch(get_sel(sinverse)) {
        case 0:/* Rational*/
          WITH->n=get_int(torder);
          switch(get_sel(srational)) {
            case 1:/*Elliptic*/
              printf("Elliptic filter\n");
             Init:
              if (WITH->n&1) {WITH->py=1; WITH->px=1;}
              else {WITH->px=0; WITH->py=0;}
              break;
            case 2:/*Irregular*/
              printf("Irregular filter\n");
              if (!filter[inuse].valid) goto Init;
          }
          break;
        case 1:/*Inverse Chebyshev*/
          printf("Inverse Chebyshev filter\n");
          WITH->n=get_int(torder);
          if (WITH->n&1) WITH->py=1; else WITH->py=0;
          WITH->px=WITH->n;
      }
      break;
    case 1:/*Butterworth*/
      printf("Butterworth filter\n");
      WITH->n=WITH->py=WITH->px=get_int(torder);
      break;
    case 2:/*Chebyshev*/
      printf("Chebyshev filter\n");
      WITH->n=get_int(torder);
      if (WITH->n&1) WITH->px=1; else WITH->px=0;
      WITH->py=WITH->n;
      break;
    case 3:/*Bessel*/;
      printf("Bessel filters not implemented. Butterworth filter instead\n");
      WITH->n=WITH->py=WITH->px=get_int(torder);
      break;
  }
  /* Computing the low-pass approximation */
  WITH->epsilon=sqrtl(powl(10.0,0.1*WITH->Amax)-1);
  printf("epsilon: %10.6Lf\n",WITH->epsilon);
  WITH->alfa=sqrtl(sqrtl(powl(10.0,0.1*WITH->Amin)-1)/WITH->epsilon);
  printf("alpha:   %10.6Lf\n",WITH->alfa);
  if (!filter[inuse].valid) {
    FDefault(WITH->n, WITH->px, WITH->fx);
    FDefault(WITH->n, WITH->py, WITH->fy);
    set_int(tpx,WITH->px);
    set_int(tpy,WITH->py);
    set_max(tpx,WITH->n);
    set_max(tpy,WITH->n);
    set_max(tchangefx,(WITH->n-WITH->px)/2);
    set_max(tchangefy,(WITH->n-WITH->py)/2);
  }
  if (get_sel(srational)==2) {
    update(tpx); /* Will open the parameters window */
    update(tpy);
    Ntchangefx(NULL);
    Ntchangefy(NULL);
  }
  else CompleteDesign(WITH);
}

void AdjustTitle(Xv_opaque obj)
{
  /* Notify handler for ttitle */
  obj->v.stextfield.panel_value[8]='\0';
  update(obj);
  strcpy(filter[inuse].title,get_value(ttitle));
}

void ListDesign(int di)
{
  if (filter[di].valid) {
    printf("\nDesign #%d - %s:\n",di+1,filter[di].title);
    if (DISCRETE(di)) {
      ListPolynomial("P(z)",&filter[di].Pz);
      ListPolynomial("E(z)",&filter[di].Ez);
      if (SHOWK) ListPolynomial("F(z)",&filter[di].Fz);
      ListRoots("P(z)",&filter[di].rpk,&filter[di].Pz);
      ListRoots("E(z)",&filter[di].rek,&filter[di].Ez);
      if (SHOWK) ListRoots("F(z)",&filter[di].rfk,&filter[di].Fz);
    }
    else {
      ListPolynomial("P(s)",&filter[di].Ps);
      ListPolynomial("E(s)",&filter[di].Es);
      if (SHOWK) ListPolynomial("F(s)",&filter[di].Fs);
      ListRoots("P(s)",&filter[di].rpk,&filter[di].Ps);
      ListRoots("E(s)",&filter[di].rek,&filter[di].Es);
      if (SHOWK) ListRoots("F(s)",&filter[di].rfk,&filter[di].Fs);
    }
    if (filter[di].realized) ListBiquads(&filter[di]);
    if (!DISCRETE(di)) printf("Normalization factor: %Lg\n",filter[di].normalization);
  }
}

void SaveDesign(int di)
{
  char temp[60];
  design *item;

  item=&filter[di];
  if (item->valid) {
    strcpy(temp,item->title);
    if (DISCRETE(di)) {
      SavePolynomial(temp,"pz",&item->Pz,1);
      SavePolynomial(temp,"ez",&item->Ez,1);
      if (SHOWK) SavePolynomial(temp,"fz",&item->Fz,1);
      SaveRoots(temp,"rpz",&item->rpk,&item->Pz,1);
      SaveRoots(temp,"rez",&item->rek,&item->Ez,1);
      if (SHOWK) SaveRoots(temp,"rfz",&item->rfk,&item->Fz,1);
    }
    else {
      SavePolynomial(temp,"ps",&item->Ps,item->normalization);
      SavePolynomial(temp,"es",&item->Es,item->normalization);
      if (SHOWK) SavePolynomial(temp,"fs",&item->Fs,item->normalization);
      SaveRoots(temp,"rps",&item->rpk,&item->Ps,item->normalization);
      SaveRoots(temp,"res",&item->rek,&item->Es,item->normalization);
      if (SHOWK) SaveRoots(temp,"rfs",&item->rfk,&item->Fs,item->normalization);
    }
    if (item->realized) SaveBiquads(item);
  }
}

void DesignBiquads(Xv_opaque obj)
{
  int i,j,n1,n2;
  design *item;
  int ix,k,xa,ha,i1,i2;
  ldouble t,f,w,fatord,a1,a2,b1,b2,sr,si,wt,z1,z2;
  boolean plot;
  section *biq;

  item=&filter[inuse];
  if (!item->valid) return;
  n1=n2=0;
  for (i=1; i<=item->nb; i++) {
    for (j=0; j<2; j++) {
      if (item->biquad[i].pole[j]) n1++;
      if (item->biquad[i].zero[j]) n2++;
    }
    item->biquad[i].max=0;
  }
  if (n1!=item->np) {
    printf("Some poles were not assigned to biquads\n");
    return;
  }
  if (n2!=item->nz) {
    printf("Some zeros were not assigned to biquads\n");
    return;
  }
  while (active_w!=ffrequency) close_window(active_w);
  plot=false;
 DeNovo:
  f=get_real(twmin);
  ix=0;
  do {
    ha=(long)floorl(ix*ah+bh+0.5);
    if (DISCRETE(inuse)) fatord=1; else fatord=item->normalization;
    if (RADS)
      w=f/fatord;
    else
      w=2*M_PI*f/fatord;
    wt=w/item->sampling;
    z1=cosl(wt);
    z2=sinl(wt);
    a1=1.0;
    a2=0.0;
    b1=1.0;
    b2=0.0;
    for (i=1; i<=item->nb; i++) {
      if (DISCRETE(inuse)) {
        for (j=0; j<2; j++) {
          k=item->biquad[i].zero[j];
          if (k) {
            a1=Cmult(a1,a2,z1-item->rpk.re[k],z2-item->rpk.im[k]);
            a2=Imag;
          }
          k=item->biquad[i].pole[j];
          if (k) {
            b1=Cmult(b1,b2,z1-item->rek.re[k],z2-item->rek.im[k]);
            b2=Imag;
          }
        }
      }
      else {
        for (j=0; j<2; j++) {
          k=item->biquad[i].zero[j];
          if (k) {
            a1=Cmult(a1,a2,-item->rpk.re[k],w-item->rpk.im[k]);
            a2=Imag;
          }
          k=item->biquad[i].pole[j];
          if (k) {
            b1=Cmult(b1,b2,-item->rek.re[k],w-item->rek.im[k]);
            b2=Imag;
          }
        }
      }
      a1*=item->biquad[i].gain;
      a2*=item->biquad[i].gain;
      sr=Cdiv(a1,a2,b1,b2);
      si=Imag;
      t=sqrtl(sr*sr+si*si);
      if (plot) {
        t=20*log10l(t);
        k=flimy(t,ag,bg);
        setcolor(cor[i%7]);
        if (ix>0) line(xa,item->biquad[i].ga,ha,k);
        item->biquad[i].ga=k;
      }
      else if (t>item->biquad[i].max) item->biquad[i].max=t;
    }
    xa=ha;
    if (LOG)
      f*=dw;
    else
      f+=dw;
    ix++;
  } while (ix<=get_int(tsegmf));
  ix=get_int(tsegmf);
  ultpt=ix;
  if (!plot) {
    /* Compute gains */
    t=1;
    for (i=1; i<=item->nb; i++) {
      item->biquad[i].gain*=(t/item->biquad[i].max);
      t=item->biquad[i].max;
    }
    plot=true;
    goto DeNovo;
  }
  /* Compute coefficients */
  for (i=1; i<=item->nb; i++) {
    biq=&item->biquad[i];
    i1=biq->pole[0];
    i2=biq->pole[1];
    if (i1 && i2) {
      biq->a2=1;
      biq->a1=-item->rek.re[i1]-item->rek.re[i2];
      biq->a0=Cmult(item->rek.re[i1],item->rek.im[i1],item->rek.re[i2],item->rek.im[i2]);
    }
    else if (i1 || i2) {
      if (!i1) i1=i2;
      biq->a2=0;
      biq->a1=1;
      biq->a0=-item->rek.re[i1];
    }
    else {
      biq->a2=biq->a1=0;
      biq->a0=1;
    }
    i1=biq->zero[0];
    i2=biq->zero[1];
    if (i1 && i2) {
      biq->b2=1;
      biq->b1=-item->rpk.re[i1]-item->rpk.re[i2];
      biq->b0=Cmult(item->rpk.re[i1],item->rpk.im[i1],item->rpk.re[i2],item->rpk.im[i2]);
    }
    else if (i1 || i2) {
      if (!i1) i1=i2;
      biq->b2=0;
      biq->b1=1;
      biq->b0=-item->rpk.re[i1];
    }
    else {
      biq->b2=biq->b1=0;
      biq->b0=1;
    }
    biq->b0*=biq->gain;
    biq->b1*=biq->gain;
    biq->b2*=biq->gain;
  }
  item->realized=true;
}

void NotifyBiquads(Xv_opaque obj)
{
  int i,j;
  design *item;
  char txt[50];

  item=&filter[inuse];
  if (!item->valid) return;
  setcolor(c_black);
  settextstyle(SMALL_FONT,HORIZ_DIR,4);
  sprintf(txt,"#    poles  zeros");
  outtextxy(xd+2,0,txt);
  for (j=1; j<=item->nz; j++) {
    sprintf(txt,"%d",j);
    outtextxy((7+j)*xd+2,0,txt);
  }
  for (i=1; i<=item->nb; i++) {
    setfillstyle(SOLID_FILL,cor[i%7]);
    rectangle(xd,i*yd,xd+xd,(i+1)*yd);
    bar(xd+1,i*yd+1,xd+xd-1,(i+1)*yd-1);
    sprintf(txt,"%d",i);
    outtextxy(xd+2,i*yd,txt);
    setfillstyle(SOLID_FILL,c_white);
    for (j=0; j<2; j++) {
      rectangle((3+j)*xd,i*yd,(4+j)*xd,(i+1)*yd);
      bar((3+j)*xd+1,i*yd+1,(4+j)*xd-1,(i+1)*yd-1);
      if (item->biquad[i].pole[j]) {
        sprintf(txt,"%d",item->biquad[i].pole[j]);
        outtextxy((3+j)*xd+2,i*yd,txt);
      }
    }
    for (j=1; j<=item->nz; j++) {
      rectangle((7+j)*xd,i*yd,(8+j)*xd,(i+1)*yd);
      if (j==item->biquad[i].zero[0] || j==item->biquad[i].zero[1])
        setfillstyle(SOLID_FILL,c_cursor);
      else setfillstyle(SOLID_FILL,c_white);
      bar((7+j)*xd+1,i*yd+1,(8+j)*xd-1,(i+1)*yd-1);
    }
  }
}

void EventsBiquads(Xv_opaque obj)
{
  int i,j;
  static int pxx,pyy,k,append=0;
  design *item;

  item=&filter[inuse];
  if (!item->valid) return;
  if (!item->valid) return;
  if ((ie_code>='0' && ie_code<='9') || (ie_code==MS_LEFT) || (ie_code==MS_MIDDLE)) {
    pyy=ie_locy/yd;
    if (pyy<=item->nb) {
      if ((ie_code==MS_LEFT) || (ie_code==MS_MIDDLE)) {
        pxx=ie_locx/xd-7;
        if (pxx>0 && pxx<=item->nz) {
          if (item->biquad[pyy].zero[0]) j=1; else j=0;
          if (ie_code==MS_LEFT) {
            item->biquad[pyy].zero[j]=pxx;
            if (fabsl(item->rpk.im[pxx])>tolm)
              item->biquad[pyy].zero[(!j)&1]=item->nz+1-pxx;
            else
             if (item->biquad[pyy].zero[(!j)&1] &&
                 fabsl(item->rpk.im[item->biquad[pyy].zero[(!j)&1]])>tolm)
               item->biquad[pyy].zero[(!j)&1]=0;
            for (i=1; i<=item->nb; i++)
              if (i!=pyy)
                for (j=0; j<=1; j++)
                  if (item->biquad[i].zero[j]==pxx) {
                    item->biquad[i].zero[0]=0;
                    item->biquad[i].zero[1]=0;
                  }
          }
          else
            for (j=0; j<2; j++) item->biquad[pyy].zero[j]=0;
          NotifyBiquads(NULL);
        }
      }
      else {
        pxx=ie_locx/xd-3;
        if (pxx>=0 && pxx<=1) {
          if (!append)
            k=ie_code-'0';
          else
            k=10*append+ie_code-'0';
          if (k<=item->np) {
            append=item->biquad[pyy].pole[pxx]=k;
            if (pxx) j=0; else j=1;
            if (fabsl(item->rek.im[k])>tolm)
              item->biquad[pyy].pole[j]=item->np+1-k;
            else if (item->biquad[pyy].pole[j] &&
                    (fabsl(item->rek.im[item->biquad[pyy].pole[j]])>tolm))
              item->biquad[pyy].pole[j]=0;
          }
          else append=0;
          NotifyBiquads(NULL);
        }
      }
    }
  }
  else {
    if (append) {
      for (i=1; i<=item->nb; i++)
        for (j=0; j<=1; j++)
          if ((i!=pyy) || (j!=pxx))
            if (item->biquad[i].pole[j]==k) {
              item->biquad[i].pole[0]=0;
              item->biquad[i].pole[1]=0;
              NotifyBiquads(NULL);
            }
      append=0;
    }
  }
}

void HelpBiquad(Xv_opaque obj)
{
  tty1->v.stty.yc=tty1->dy;
  ttysw_output(tty1,"");
  printf("To design a biquad cascade:\n");
  printf("Use the poles and zeros plot as guide.\n");
  printf("1-Select pole order and pairing by pointing\n");
  printf("  the pole boxes with the mouse and typing\n");
  printf("  the pole numbers.\n");
  printf("2-Select zeros with the mouse left button.\n");
  printf("3-Press the Design button. The frequency\n");
  printf("  response to each biquad output, equalized\n");
  printf("  in the displayed range, will be displayed.\n");
  printf("4-If there is too much attenuation at pass-\n");
  printf("  band at some output, try a different order\n");
  printf("  or pairing.\n");
  printf("5-Use the Save Design menu item to save.\n");
}

void HelpIrregular(Xv_opaque obj)
{
  tty1->v.stty.yc=tty1->dy;
  ttysw_output(tty1,"");
  printf("Irregular filters:\n");
  printf("All the parameters refer to the continuous\n");
  printf("low-pass prototype.\n");
  printf("fx=Peak values of the normalized charac-\n");
  printf("  teristic function at passband.\n");
  printf("  They control the passband attenuation maxima\n");
  printf("  from low to high w. The attenuations can be\n");
  printf("  specified instead of the fx.\n");
  printf("  fx=0 create double attenuation zeros.\n");
  printf("fy=Peak values of the inverted and reflected\n");
  printf("  normalized characteristic function.\n");
  printf("  They control the stopband attenuation minima\n");
  printf("  from high to low w. The attenuations can be\n");
  printf("  specified instead of the fy.\n");
  printf("  fy=0 create double transmission zeros.\n");
  printf("The default values produce an elliptic filter.\n");
}

void ProcessMenu1(Xv_opaque obj)
{
  int k,di;

  /* Notify handler for menu1 */
  switch (obj->v.smenu.sel_menu) {
    case 1: /* approximation */
      open_window(fapproximation);
      OpenFrequency(NULL);
      break;
    case 2: /* parameters */
      open_window(fparameters);
      break;
    case 3: /* roots */
      if (filter[inuse].valid) {
	k=froots->v.sframe.mapped;
	open_window(froots);
	if (k && xv_ok) NotifyRoots(NULL);
      }
      else printf("No filter designed.\n");
      break;
    case 4: /* list design */
      ListDesign(inuse);
      break;
    case 5: /* save design */
      SaveDesign(inuse);
      break;
    case 6: /* list designs */
      for (di=0; di<=ndesigns; di++) ListDesign(di);
      break;
    case 7: /* save designs */
      for (di=0; di<=ndesigns; di++) SaveDesign(di);
      break;
    case 8:  /* design biquad cascade */
      if (filter[inuse].valid) open_window(fbiquad);
      else printf("No approximation made.\n");
      break;
    case 9:  /* biquad multipliers */
      if (filter[inuse].realized) {
        if (DISCRETE(inuse))
          ComputeMultipliers(&filter[inuse]);
        else printf("Multipliers are only for digital filters.\n");
      }
      else printf("No biquads designed.\n");
      break;
    case 10: /* precision */
      open_window(fprecision);
      break;
    case 11: /* messages */
      open_window(fmessages);
      break;
    case 12: /* biquad structure */
      open_window(fcircuit);
      break;
    case 13: /* quit */;
      if (notice("Quit?")) xv_end=1;
  }
}

void main()
{
  design *WITH;
  /* Inicialization */
  use_palette=0;
  for (inuse=0; inuse<maxdesigns; inuse++) {
    WITH=&filter[inuse];
    if ((WITH->Gan=malloc((xxmax+1)*sizeof(ldouble)))!=NULL) {
      if ((WITH->Ang=malloc((xxmax+1)*sizeof(ldouble)))!=NULL) {
        if ((WITH->Tg=malloc((xxmax+1)*sizeof(ldouble)))!=NULL)  {
          ndesigns=inuse;
          sprintf(WITH->title,"filter%d",inuse+1);
          WITH->valid=false;
          WITH->Es.grau=0;
          WITH->Fs.grau=0;
          WITH->Ps.grau=0;
          WITH->Ez.grau=0;
          WITH->Fz.grau=0;
          WITH->Pz.grau=0;
          WITH->Es.a[0]=1;
          WITH->Fs.a[0]=1;
          WITH->Ps.a[0]=1;
          WITH->Ez.a[0]=1;
          WITH->Fz.a[0]=1;
          WITH->Pz.a[0]=1;
          WITH->Es.cte=1;
          WITH->Fs.cte=1;
          WITH->Ps.cte=1;
          WITH->Ez.cte=1;
          WITH->Fz.cte=1;
          WITH->Pz.cte=1;
          WITH->type=1;
          WITH->pol=1;
          WITH->inv=0;
          WITH->rat=0;
          WITH->order=5;
          WITH->anadig=1;
          WITH->sampling=10;
          WITH->Amax=1;
          WITH->Amin=40;
          WITH->normalization=1;
        }
        else {free(WITH->Gan); free(WITH->Ang); break;}
      }
      else {free(WITH->Gan); break;}
    }
    else break;
  }
  inuse=0;
  srand(1);
  normal_bsize=20000;
  xv_init(0,0);
  /* Menu creation */
  menu1=xv_create(NULL,MENU,
    XV_LABEL,"Menu",
    ITEM_MENU,
      "approximation",
      "frequency response",
      "poles and zeros",
      "list design",
      "save design",
      "list all designs",
      "save all designs",
      "design biquad cascade",
      "biquad multipliers",
      "precision control",
      "messages",
      "biquad structure",
      "quit",
    NULL,
    SEL_MENU,1,
    NOTIFY_HANDLER,ProcessMenu1,
    NULL);
  /* Interface objects creation */

  ffrequency=xv_create(NULL,FRAME,
    XV_LABEL,"Filter Designer",
    DX,getmaxx(),
    DY,getmaxy(),
    MENU_NAME,menu1,
    NULL);
  cfrequency=xv_create(ffrequency,CANVAS,
    FORE_COLOR,15,
    BACK_COLOR,0,
    NOTIFY_HANDLER,NotifyFrequency,
    EVENT_HANDLER,EventsFrequency,
    MENU_NAME,menu1,
    NULL);

  fmessages=xv_create(NULL,FRAME,
    XV_LABEL,"Messages",
    X,330,
    Y,240,
    DX,309,
    DY,239,
    MENU_NAME,menu1,
    NULL);
  tty1=xv_create(fmessages,TTY,
    NULL);

  fapproximation=xv_create(NULL,FRAME,
    XV_LABEL,"Approximation",
    X,7,
    Y,24,
    DX,445,
    DY,177,
    MENU_NAME,menu1,
    NULL);
  stype=xv_create(fapproximation,SETTING,
    XV_LABEL,"Filter type",
    ITEM_SETTING,
      "low-pass",
      "high-pass",
      "band-pass",
      "band-reject",
    NULL,
    EXCLUSIVE,1,
    NOTIFY_HANDLER,OpenFrequency,
    NULL);
  spolynomial=xv_create(fapproximation,SETTING,
    XV_LABEL,"Approximation",
    Y,15,
    ITEM_SETTING,
      "Butterworth",
      "Chebyshev",
      /*"Bessel",*/
    NULL,
    EXCLUSIVE,1,
    NOTIFY_HANDLER,ProcessPolynomial,
    NULL);
  sinverse=xv_create(fapproximation,SETTING,
    EXCLUSIVE,1,
    Y,30,X,104,
    ITEM_SETTING,
      "Inverse Chebyshev",
    NULL,
    NOTIFY_HANDLER,ProcessInverse,
    NULL);
  srational=xv_create(fapproximation,SETTING,
    Y,45,X,104,
    ITEM_SETTING,
      "Elliptic",
      "Irregular",
    NULL,
    EXCLUSIVE,1,
    NOTIFY_HANDLER,ProcessRational,
    NULL);
  tnumber=xv_create(fapproximation,TEXTFIELD,
    XV_LABEL,"Design #",
    X,310,Y,135,
    FORE_COLOR,RED,
    VALUE_LENGTH,5,
    FIELD_TYPE,int_field,
    PANEL_INT,1,
    MIN_VALUE,1,
    MAX_VALUE,ndesigns,
    NOTIFY_HANDLER,SelectDesign,
    NULL);
  torder=xv_create(fapproximation,TEXTFIELD,
    XV_LABEL,"Order of low-pass prototype",
    Y,60,
    VALUE_LENGTH,4,
    FIELD_TYPE,int_field,
    MAX_VALUE,nmax,
    MIN_VALUE,1,
    NOTIFY_HANDLER,InvalidateDesign,
    NULL);
  sanadig=xv_create(fapproximation,SETTING,
    XV_LABEL,"Time",
    ITEM_SETTING,"Continuous","Digital bilinear","Digital LDI",NULL,
    Y,75,
    EXCLUSIVE,true,
    NOTIFY_HANDLER,InvalidateDesign,
    NULL);
  tsampling=xv_create(fapproximation,TEXTFIELD,
    XV_LABEL,"Sampling frequency (Hz)",
    Y,90,
    VALUE_LENGTH,10,
    FIELD_TYPE,real_field,
    NOTIFY_HANDLER,InvalidateDesign,
    NULL);
  tamin=xv_create(fapproximation,TEXTFIELD,
    XV_LABEL,"Min stopband attenuation (dB)",
    Y,105,
    FIELD_TYPE,real_field,
    NULL);
  tamax=xv_create(fapproximation,TEXTFIELD,
    XV_LABEL,"Max passband attenuation (dB)",
    Y,120,
    FIELD_TYPE,real_field,
    NULL);
  ttitle=xv_create(fapproximation,TEXTFIELD,
    XV_LABEL,"Title",
    Y,135,X,80,
    NOTIFY_HANDLER,AdjustTitle,
    NULL);
  bapplyapprox=xv_create(fapproximation,BUTTON,
    XV_LABEL,"Design",
    Y,135,
    NOTIFY_HANDLER,ApplyApprox,
    NULL);

  fbplimits=xv_create(NULL,FRAME,
    XV_LABEL,"Band-Pass frequency limits",
    X,7,
    Y,202,
    DX,319,
    DY,101,
    MENU_NAME,menu1,
    NULL);
  tbpf1=xv_create(fbplimits,TEXTFIELD,
    XV_LABEL,"lower stopband border",
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.5",
    NULL);
  tbpf2=xv_create(fbplimits,TEXTFIELD,
    XV_LABEL,"lower passband border",
    Y,15,
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.8",
    NULL);
  tbpf3=xv_create(fbplimits,TEXTFIELD,
    XV_LABEL,"upper passband border",
    Y,30,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.25",
    NULL);
  tbpf4=xv_create(fbplimits,TEXTFIELD,
    XV_LABEL,"upper stopband border",
    Y,45,
    FIELD_TYPE,real_field,
    PANEL_REAL,"2",
    NULL);
  bapplyfBP=xv_create(fbplimits,BUTTON,
    XV_LABEL,"Apply",
    Y,62,
    NOTIFY_HANDLER,ProcessfBP,
    NULL);

  fbrlimits=xv_create(NULL,FRAME,
    XV_LABEL,"Band-Reject frequency limits",
    X,7,
    Y,202,
    DX,319,
    DY,100,
    MENU_NAME,menu1,
    NULL);
  tbrf1=xv_create(fbrlimits,TEXTFIELD,
    XV_LABEL,"lower passband border",
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.5",
    NULL);
  tbrf2=xv_create(fbrlimits,TEXTFIELD,
    XV_LABEL,"lower stopband border",
    Y,15,
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.8",
    NULL);
  tbrf3=xv_create(fbrlimits,TEXTFIELD,
    XV_LABEL,"upper stopband border",
    Y,30,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.25",
    NULL);
  tbrf4=xv_create(fbrlimits,TEXTFIELD,
    XV_LABEL,"upper passband border",
    Y,45,
    FIELD_TYPE,real_field,
    PANEL_REAL,"2",
    NULL);
  bapplyfbr=xv_create(fbrlimits,BUTTON,
    XV_LABEL,"Apply",
    Y,60,
    NOTIFY_HANDLER,Processfbr,
    NULL);

  flplimits=xv_create(NULL,FRAME,
    XV_LABEL,"Low-Pass filter frequency limits",
    X,7,
    Y,202,
    DX,319,
    DY,69,
    DYMIN,27,
    MENU_NAME,menu1,
    NULL);
  tlpf1=xv_create(flplimits,TEXTFIELD,
    XV_LABEL,"passband border",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1",
    NULL);
  tlpf2=xv_create(flplimits,TEXTFIELD,
    XV_LABEL,"stopband border",
    Y,15,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.2",
    NULL);
  bapplyflp=xv_create(flplimits,BUTTON,
    XV_LABEL,"Apply",
    Y,30,
    NOTIFY_HANDLER,ProcessfLP,
    NULL);

  fhplimits=xv_create(NULL,FRAME,
    XV_LABEL,"High-Pass filter frequency limits",
    X,7,
    Y,202,
    DX,319,
    DY,70,
    DYMIN,27,
    MENU_NAME,menu1,
    NULL);
  thpf1=xv_create(fhplimits,TEXTFIELD,
    XV_LABEL,"stopband border",
    FIELD_TYPE,real_field,
    PANEL_REAL,"1",
    NULL);
  thpf2=xv_create(fhplimits,TEXTFIELD,
    XV_LABEL,"passband border",
    Y,15,
    FIELD_TYPE,real_field,
    PANEL_REAL,"1.2",
    NULL);
  bapplyfhp=xv_create(fhplimits,BUTTON,
    XV_LABEL,"Apply",
    Y,30,
    NOTIFY_HANDLER,ProcessfHP,
    NULL);

  froots=xv_create(NULL,FRAME,
    XV_LABEL,"Poles and Zeros",
    Y,259,
    DX,354,
    DY,239,
    MENU_NAME,menu1,
    NULL);
  croots=xv_create(froots,CANVAS,
    FORE_COLOR,15,
    BACK_COLOR,0,
    NOTIFY_HANDLER,NotifyRoots,
    EVENT_HANDLER,EventsRoots,
    MENU_NAME,menu1,
    NULL);

  fparameters=xv_create(NULL,FRAME,
    XV_LABEL,"Frequency response parameters",
    X,314,
    Y,39,
    DX,319,
    DY,219,
    MENU_NAME,menu1,
    NULL);
  twmin=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Minimum frequency",
    VALUE_LENGTH,20,
    FIELD_TYPE,real_field,
    PANEL_REAL,"0.2",
    NOTIFY_HANDLER,InvalidateFrequency,
    NULL);
  twmax=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Maximum frequency",
    Y,15,
    VALUE_LENGTH,20,
    FIELD_TYPE,real_field,
    PANEL_REAL,"5",
    NOTIFY_HANDLER,InvalidateFrequency,
    NULL);
  tgmin=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Minimum gain (dB)",
    Y,30,
    VALUE_LENGTH,20,
    FIELD_TYPE,real_field,
    PANEL_REAL,"-80",
    NULL);
  tgmax=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Maximum gain (dB)",
    Y,45,
    VALUE_LENGTH,20,
    FIELD_TYPE,real_field,
    PANEL_REAL,"10",
    NULL);
  slog=xv_create(fparameters,SETTING,
    XV_LABEL,"Frequency scale",
    Y,90,
    ITEM_SETTING,
      "linear",
      "logarithmic",
    NULL,
    EXCLUSIVE,1,
    SEL_SETTING,2,
    NOTIFY_HANDLER,InvalidateFrequency,
    NULL);
    sHertz=xv_create(fparameters,SETTING,
    XV_LABEL,"Frequency unit ",
    Y,105,
    ITEM_SETTING,
      "Hz",
      "rd/s",
    NULL,
    EXCLUSIVE,1,
    SEL_SETTING,2,
    NOTIFY_HANDLER,InvalidateFrequency,
    NULL);
  tdmin=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Minimum delay (s)",
    Y,60,
    VALUE_LENGTH,20,
    FIELD_TYPE,real_field,
    PANEL_REAL,"-10",
    NULL);
  tdmax=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Maximum delay (s)",
    Y,76,
    VALUE_LENGTH,20,
    FIELD_TYPE,real_field,
    PANEL_REAL,"50",
    NULL);
  splot=xv_create(fparameters,SETTING,
    XV_LABEL,"Plot",
    Y,120,
    ITEM_SETTING,
      "grid",
      "limits",
      "phase",
      "delay",
    NULL,
    SEL_SETTING,3,
    NULL);
  tsegmf=xv_create(fparameters,TEXTFIELD,
    XV_LABEL,"Segments in the plots",
    Y,135,
    VALUE_LENGTH,6,
    FIELD_TYPE,int_field,
    PANEL_INT,299,
    MAX_VALUE,xxmax,
    NOTIFY_HANDLER,InvalidateFrequency,
    NULL);
  scolor=xv_create(fparameters,SETTING,
    XV_LABEL,"Color curves",
    ITEM_SETTING,"by type","by design",NULL,
    EXCLUSIVE,true,
    SEL_SETTING,1,
    Y,150,
    NULL);
  sfunction=xv_create(fparameters,SETTING,
    XV_LABEL,"Function to plot",
    ITEM_SETTING,"1/H(jw)","1/K(jw)",NULL,
    EXCLUSIVE,true,
    SEL_SETTING,1,
    Y,165,
    NOTIFY_HANDLER,InvalidateFrequency,
    NULL);
  sk=xv_create(fparameters,SETTING,
    XV_LABEL,"List/Save K(s) and K(z)",
    ITEM_SETTING,"no","yes",NULL,
    EXCLUSIVE,true,
    SEL_SETTING,1,
    Y,180,X,50,
    NULL);
  bapplyparameters=xv_create(fparameters,BUTTON,
    XV_LABEL,"Apply",
    Y,180,
    NOTIFY_HANDLER,ApplyParameters,
    NULL);

  fprecision=xv_create(NULL,FRAME,
    XV_LABEL,"Precision control parameters",
    DX,319,
    DY,100,
    MENU_NAME,menu1,
    NULL);
  timax=xv_create(fprecision,TEXTFIELD,
    XV_LABEL,"Max. number of iterations",
    VALUE_LENGTH,5,
    FIELD_TYPE,int_field,
    MIN_VALUE,1,
    PANEL_INT,IMAX,
    NULL);
  ttolr=xv_create(fprecision,TEXTFIELD,
    XV_LABEL,"Min. tol. for roots",
    FIELD_TYPE,real_field,
    PANEL_REAL,tolr,
    Y,15,
    NULL);
  ttolrmax=xv_create(fprecision,TEXTFIELD,
    XV_LABEL,"Max. tol. for roots",
    FIELD_TYPE,real_field,
    PANEL_REAL,tolrmax,
    Y,30,
    NULL);
  tikmax=xv_create(fprecision,TEXTFIELD,
    XV_LABEL,"Max. iter. before inversion",
    VALUE_LENGTH,5,
    FIELD_TYPE,int_field,
    MIN_VALUE,1,
    Y,45,
    PANEL_INT,IKMAX,
    NULL);
  ttolo=xv_create(fprecision,TEXTFIELD,
    XV_LABEL,"Tol. for optimization",
    FIELD_TYPE,real_field,
    PANEL_REAL,tolo,
    Y,60,
    NULL);

  firregular=xv_create(NULL,FRAME,
    XV_LABEL,"Irregular filter specifications",
    X,56,
    Y,63,
    DX,278,
    DY,129,
    MENU_NAME,menu1,
    NULL);
  tpx=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"Atten. zeros at zero    ",
    VALUE_LENGTH,5,
    FIELD_TYPE,int_field,
    MIN_VALUE,0,
    NOTIFY_HANDLER,Npx,
    NULL);
  tpy=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"Trans. zeros at infinity",
    Y,15,
    VALUE_LENGTH,5,
    FIELD_TYPE,int_field,
    MIN_VALUE,0,
    NOTIFY_HANDLER,Npy,
    NULL);
  tchangefx=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"Change fx",
    Y,30,
    VALUE_LENGTH,4,
    FIELD_TYPE,int_field,
    PANEL_INT,1,
    MIN_VALUE,1,
    NOTIFY_HANDLER,Ntchangefx,
    NULL);
  tfxto=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"to",
    X,112,
    Y,30,
    FIELD_TYPE,real_field,
    NOTIFY_HANDLER,Changefx,
    NULL);
  tchangeAx=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"Passband att(dB)",
    Y,45,
    FIELD_TYPE,real_field,
    NOTIFY_HANDLER,ChangeAx,
    NULL);
  tchangefy=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"Change fy",
    Y,60,
    VALUE_LENGTH,4,
    FIELD_TYPE,int_field,
    PANEL_INT,1,
    MIN_VALUE,1,
    NOTIFY_HANDLER,Ntchangefy,
    NULL);
  tfyto=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"to",
    X,112,
    Y,60,
    FIELD_TYPE,real_field,
    NOTIFY_HANDLER,Changefy,
    NULL);
  tchangeAy=xv_create(firregular,TEXTFIELD,
    XV_LABEL,"Stopband att(dB)",
    Y,75,
    FIELD_TYPE,real_field,
    NOTIFY_HANDLER,ChangeAy,
    NULL);
  blistf=xv_create(firregular,BUTTON,
    XV_LABEL,"List extremes",
    Y,90,
    NOTIFY_HANDLER,ListExtremes,
    NULL);
  bcomplete=xv_create(firregular,BUTTON,
    XV_LABEL,"Complete design",
    X,114,
    Y,90,
    NOTIFY_HANDLER,Complete,
    NULL);
  bhelpirr=xv_create(firregular,BUTTON,
    XV_LABEL,"?",
    X,250,
    NOTIFY_HANDLER,HelpIrregular,
    NULL);

  fbiquad=xv_create(NULL,FRAME,
    XV_LABEL,"Pole-Zero pairing/order",
    X,7,
    Y,24,
    DX,445,
    DY,177,
    MENU_NAME,menu1,
    NULL);
  cbiquad=xv_create(fbiquad,CANVAS,
    Y,15,
    NOTIFY_HANDLER,NotifyBiquads,
    EVENT_HANDLER,EventsBiquads,
    NULL);
  bbiquad=xv_create(fbiquad,BUTTON,
    XV_LABEL,"Design biquads",
    NOTIFY_HANDLER,DesignBiquads,
    NULL);
  bhelpbiquad=xv_create(fbiquad,BUTTON,
    XV_LABEL,"?",
    X,125,
    NOTIFY_HANDLER,HelpBiquad,
    NULL);
  fcircuit=xv_create(NULL,FRAME,
    XV_LABEL,"Digital biquad structure",
    DX,486+2*mrgx,
    DY,141+mrgx+mrgy,
    RESIZE_CORNERS,0,
    NULL);
  mcircuit=xv_create(fcircuit,MESSAGE,
    ICON_MSG,1,
    XV_LABEL,"biquad.bmp",
    NULL);
  open_window(ffrequency);
  open_window(flplimits);
  printf("Filter Designer\n");
  printf("Version %s\n",version);
  printf("By Antonio Carlos M. de Queiroz\n");
  printf("COPPE/Escola de Engenharia\nUniversidade Federal do Rio de Janeiro\n");
  printf("E-mail: acmq@coe.ufrj.br\n");
  printf("Free memory: %ld bytes\n",maxavail());
  printf("Maximum number of designs: %d\n",ndesigns);
  SelectDesign(NULL);
  xv_main_loop(fapproximation);
  /* Exit */
  restorecrtmode();
}